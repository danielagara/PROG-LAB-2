﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_word
{
    class Conversor
    {
        //
        public static string EnteroBinario(int decimalC)
        {
            int j=0;
            int numAux=0;
            //int numeroBin[];
            string numeroBin;
            while ((numAux == 2) || (numAux==3))
            {
                numAux = decimalC / 2;
                numeroBin[j]=decimalC % 2;
                j++;
            }
            return numeroBin;
            
        }


        /*
        public static double BinarioDecimal(string binarioC)
        {

        }*/
    }
}
