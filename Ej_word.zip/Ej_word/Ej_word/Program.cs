﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_word
{
    class Program
    {
        static void Main(string[] args)
        {
            string numeroBinario;

            Console.WriteLine("INGRESE UN NUMERO");
            int numeroIngresado;
            int.TryParse(Console.ReadLine(), out numeroIngresado);
            numeroBinario=Conversor.EnteroBinario(numeroIngresado);
            Console.WriteLine("NUM BINARIO {0}", numeroBinario);
        }
    }
}
