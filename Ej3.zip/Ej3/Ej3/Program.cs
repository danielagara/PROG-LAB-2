﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej3
{
    //Mostrar por pantalla todos los números primos que haya hasta el número que ingrese el usuario por consola.
    class Program
    {//REHACER
        static void Main(string[] args)
        {
            Console.WriteLine("INGRESE UN NUMERO");
            string numAux = Console.ReadLine();
            int numIngresado=(Int16.Parse(numAux));
            List<int> numerosPrimos = new List<int>();
            
            for (int i = numIngresado; i >= 0; i--)
            {
                if (i % 2 != 0)
                {
                    numerosPrimos.Add(i);
                    Console.WriteLine("NUM PRIMO = {0}", i);
                }
            }
        }
    }
}
