﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_31
{
    class Program
    {
        static void Main(string[] args)
        {

           /* Cliente cliente1 = new Cliente(1, "Daniela");
            Cliente cliente2 = new Cliente(2, "Ana");
            Cliente cliente3 = new Cliente(3, "Mariel");

            Negocio negocio = new Negocio();
            if (negocio + cliente1)
            {
                Console.WriteLine("EL CLIENTE ES: {0} {1}", negocio.Cliente
            }*/
        }
    }
}
