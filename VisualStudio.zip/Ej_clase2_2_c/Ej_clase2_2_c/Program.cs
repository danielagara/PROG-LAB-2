﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_clase2_2_c
{
    class Program
    {
        static void Main(string[] args)
        {
            string myString="";
            //if (!myString.EndsWith("hola"))
            //{
            //    Console.WriteLine("no");
            //}
            myString="La clase de las listas".Substring(5,8);
            Console.WriteLine("{0}",myString);
            Console.ReadKey();
        }
    }
}
