﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garat.Daniela._2D
{
    public class Perro : Mascota
    {
        #region Atributos
        
        private int edad;
        private bool esAlfa;
        
        #endregion

        #region Constructores

        public Perro(string nombre, string raza)
        :base(nombre, raza)
        {
            this.edad = 0;
            this.esAlfa = false;
        }//revisar

        public Perro(string nombre, string raza, int edad, bool esAlfa)
            :this(nombre, raza)
        {
            this.edad = edad;
            this.esAlfa = esAlfa;
        }
        #endregion

        #region Propiedades

        public int Edad
        {
            get
            {
                return this.edad;
            }

            set
            {
                this.edad = value;
            }
        }

        public bool EsAlfa
        {
            get
            {
                return this.esAlfa;
            }

            set 
            {
                this.esAlfa = value;
            }
        }

        #endregion

        #region Operadores

        public static bool operator ==(Perro perro1, Perro perro2)
        {
            bool retorno = false;
            if ((perro1.Nombre == perro2.Nombre) && (perro1.Raza == perro2.Raza) && (perro1.Edad == perro2.Edad))
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }

        public static bool operator !=(Perro perro1, Perro perro2)
        {
            bool retorno = false;
            if ((perro1.Nombre != perro2.Nombre) && (perro1.Raza != perro2.Raza) && (perro1.Edad != perro2.Edad))
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }

        public static explicit operator int(Perro perro) //revisar
        {
            return perro.Edad;
        }

        #endregion

        #region Metodos

        protected override string Ficha()
        {
            StringBuilder sb = new StringBuilder();
            if (this.esAlfa == true)
            {
                sb.AppendLine(this.Nombre + " " + this.Raza +", alfa de la manada, " + "edad " + this.Edad.ToString());
            }
            else if(this.esAlfa==false)
            {
                sb.AppendLine(this.Nombre + " "+this.Raza +", edad " + this.Edad.ToString());
            }

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object perro)
        {
            bool retorno = false;

            if (perro == this)
            {
                retorno = true;
            }

            return retorno;
        }

        #endregion
    }
}
