﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Ej_55
{
    public partial class Form1 : Form
    {
        public Stream myStream;

        public Form1()
        {
            InitializeComponent();
            toolStripStatusLabel1.Text = richTextBox1.Text.Length.ToString();
        }

        

        private void archivoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //FUNCA
            string texto = "";

            StreamReader myStr;

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    //this.stream= openFileDialog1.OpenFile();
                    this.myStream = openFileDialog1.OpenFile();
                    myStr= new StreamReader(this.myStream);
                    if (myStr != null)
                    {
                        texto=myStr.ReadToEnd();
                        richTextBox1.Text = texto;
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }

        }

        private void guardarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //NO FUNCA
            StreamWriter myStw = null;

            try
            {
                myStw = new StreamWriter(this.myStream.ToString());
                myStw.WriteLine(richTextBox1.Text);
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(this.myStream.ToString());
            }
            myStw.Close();
         }

        private void guardarComoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //FUNCA
            StreamWriter myStw = null;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                
                myStw=new StreamWriter(saveFileDialog1.OpenFile());
                if (myStw != null)
                {
                    myStw.WriteLine(richTextBox1.Text);
                    myStw.Close();
                }
            } 
        }

        private void toolStripStatusLabel1_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = richTextBox1.Text.Length.ToString();
        }
    }
}
