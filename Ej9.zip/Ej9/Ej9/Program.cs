﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej9
{
    /*Escribir un programa que imprima por pantalla una pirámide. El usuario indicará cuál será la altura de la pirámide 
    ingresando un número entero positivo. Para el ejemplo anterior la altura ingresada fue de 5.*/
    class Program
    {
        static void Main(string[] args)
        {
            int alturaPiramide;
            Console.WriteLine("INGRESE LA ALTURA DE LA PIRAMIDE:");
            alturaPiramide = Int32.Parse(Console.ReadLine());

            for (int i = alturaPiramide; i > 1; i--)
            {
                Console.WriteLine("*");
            }
        }
    }
}
