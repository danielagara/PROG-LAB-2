﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moneda
{
    public class Pesos
    {
        private double cantidad;
        private static float cotizRespectoDolar = 17.55F;

        private Pesos()
        {
        }

        public Pesos(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Pesos(double cantidad, float nuevaCotizacion) : this(cantidad)
        {
            this.cantidad = cantidad;
            cotizRespectoDolar = nuevaCotizacion;
        }

        public static float GetCotizacion()
        {
            return cotizRespectoDolar;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static explicit operator Dolar(Pesos p)
        {
            Dolar output = new Dolar(p.cantidad / Pesos.GetCotizacion());
            return output;
        }

        public static explicit operator Euro(Pesos p)
        {
            Euro output = new Euro((p.cantidad / Pesos.GetCotizacion()) * Euro.GetCotizacion());
            return output;
        }

        public static implicit operator Pesos(double d)
        {
            Pesos output = new Pesos(d);
            return output;
        }

        public static Pesos operator -(Pesos p, Dolar d)
        {
            Pesos output = new Pesos(p.cantidad - (d.GetCantidad() * Pesos.GetCotizacion()));
            return output;
        }

        public static Pesos operator -(Pesos p, Euro e)
        {
            Pesos output = new Pesos(p.cantidad - ((e.GetCantidad() / Euro.GetCotizacion() ) * Pesos.GetCotizacion()));
            return output;
        }

        public static Pesos operator +(Pesos p, Dolar d)
        {
            Pesos output = new Pesos(p.cantidad + (d.GetCantidad() * Pesos.GetCotizacion()));
            return output;
        }

        public static Pesos operator +(Pesos p, Euro e)
        {
            Pesos output = new Pesos(p.cantidad + ((e.GetCantidad() / Euro.GetCotizacion()) * Pesos.GetCotizacion()));
            return output;
        }

        public static bool operator !=(Pesos p, Dolar d)
        {
            bool output = true;
            if (d.GetCantidad() == (p.cantidad / Pesos.GetCotizacion())) output = false;
            return output;
        }
        
        public static bool operator !=(Pesos p, Euro e)
        {
            bool output = true;
            if (e.GetCantidad() == (p.GetCantidad() / Pesos.GetCotizacion()) * Euro.GetCotizacion()) output = false;
            return output;
        }

        public static bool operator !=(Pesos p1, Pesos p2)
        {
            bool output = true;
            if (p1.cantidad == p2.cantidad) output = false;
            return output;
        }

        public static bool operator ==(Pesos p, Dolar d)
        {
            bool output = false;
            if (d.GetCantidad() == (p.cantidad / Pesos.GetCotizacion())) output = true;
            return output;
        }

        public static bool operator ==(Pesos p, Euro e)
        {
            bool output = false;
            if (e.GetCantidad() == (p.GetCantidad() / Pesos.GetCotizacion()) * Euro.GetCotizacion()) output = true;
            return output;
        }

        public static bool operator ==(Pesos p1, Pesos p2)
        {
            bool output = false;
            if (p1.cantidad == p2.cantidad) output = true;
            return output;
        }
    }
}
