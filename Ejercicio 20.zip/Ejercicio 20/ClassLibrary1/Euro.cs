﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moneda
{
    public class Euro
    {
        private double cantidad;
        private static float cotizRespectoDolar = 0.7330F;

        private Euro()
        {
        }

        public Euro(double cantidad)
        {
            this.cantidad = cantidad;
        }

        public Euro(double cantidad, float nuevaCotizacion):this(cantidad)
        {
            cotizRespectoDolar = nuevaCotizacion;
        }

        public static float GetCotizacion()
        {
            return cotizRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static explicit operator Dolar(Euro e)
        {
            Dolar output = new Dolar(e.cantidad / Euro.GetCotizacion());
            return output;
        }

        public static explicit operator Pesos(Euro e)
        {
            Pesos output = new Pesos(Pesos.GetCotizacion() * (e.GetCantidad() / Euro.GetCotizacion())); 
            return output;
        }

        public static implicit operator Euro(double d)
        {
            Euro output = new Euro(d);
            return output;
        }

        public static Euro operator -(Euro e, Dolar d)
        {
            Euro output = new Euro(e.cantidad - (d.GetCantidad() * Euro.GetCotizacion()));
            return output;
        }

        public static Euro operator -(Euro e, Pesos p)
        {
            Euro output = new Euro(e.cantidad - ((p.GetCantidad() / Pesos.GetCotizacion() ) * Euro.GetCotizacion()));
            return output;
        }

        public static Euro operator +(Euro e, Dolar d)
        {
            Euro output = new Euro(e.cantidad + (d.GetCantidad() * Euro.GetCotizacion()));
            return output;
        }

        public static Euro operator +(Euro e, Pesos p)
        {
            Euro output = new Euro(e.cantidad + ((p.GetCantidad() / Pesos.GetCotizacion() ) * Euro.GetCotizacion()));
            return output;
        }

        public static bool operator !=(Euro e, Dolar d)
        {
            bool output = true;
            if (d.GetCantidad() == e.GetCantidad() / Euro.GetCotizacion()) output = false;
            return output;
        }

        public static bool operator !=(Euro e, Pesos p)
        {
            bool output = true;
            if (p.GetCantidad() == (e.GetCantidad() / Euro.GetCotizacion()) * Pesos.GetCotizacion()) output = false;
            return output;
        }

        public static bool operator !=(Euro e1, Euro e2)
        {
            bool output = true;
            if (e1.cantidad == e2.cantidad) output = false;
            return output;
        }

        public static bool operator ==(Euro e, Dolar d)
        {
            bool output = false;
            if (d.GetCantidad() == e.GetCantidad() / Euro.GetCotizacion()) output = true;
            return output;
        }

        public static bool operator ==(Euro e, Pesos p)
        {
            bool output = false;
            if (p.GetCantidad() == (e.GetCantidad() / Euro.GetCotizacion()) * Pesos.GetCotizacion()) output = true;
            return output;
        }

        public static bool operator ==(Euro e1, Euro e2)
        {
            bool output = false;
            if (e1.cantidad == e2.cantidad) output = true;
            return output;
        }
    }
}
