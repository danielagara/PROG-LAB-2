﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Moneda
{
    public class Dolar
    {
        private double cantidad;
        private static float cotizRespectoDolar = 1;

        private Dolar()
        {
            this.cantidad = 0;
            cotizRespectoDolar = 1;
        }

        public Dolar(double cantidad)
            : this()
        {
            this.cantidad = cantidad;
        }

        public Dolar(double cantidad, float nuevaCotizacion)
            : this(cantidad)
        {
            cotizRespectoDolar = nuevaCotizacion;
        }

        public double GetCantidad()
        {
            return this.cantidad;
        }
        public static float GetCotizacion()
        {
            return cotizRespectoDolar;
        }

        public static explicit operator Euro(Dolar d)
        {
            Euro output = new Euro(d.cantidad * Euro.GetCotizacion());
            return output;
        }

        public static explicit operator Pesos(Dolar d)
        {
            Pesos output = new Pesos(d.cantidad * Pesos.GetCotizacion());
            return output;
        }

        public static implicit operator Dolar(double d)
        {
            Dolar output = new Dolar(d);
            return output;
        }

        public static bool operator !=(Dolar d, Euro e)
        {
            bool output = true;
            if (d.GetCantidad() == e.GetCantidad() / Euro.GetCotizacion()) output = false;
            return output;
        }

        public static bool operator !=(Dolar d, Pesos p)
        {
            bool output = true;
            if (d.GetCantidad() == p.GetCantidad() / Dolar.GetCotizacion()) output = false;
            return output;
        }

        public static bool operator !=(Dolar d1, Dolar d2)
        {
            bool output = true;
            if (d1.cantidad == d2.cantidad) output = false;
            return output;
        }

        public static bool operator ==(Dolar d, Euro e)
        {
            bool output = false;
            if (d.GetCantidad() == e.GetCantidad() / Euro.GetCotizacion()) output = true;
            return output;
        }

        public static bool operator ==(Dolar d, Pesos p)
        {
            bool output = false;
            if (d.GetCantidad() == p.GetCantidad() / Dolar.GetCotizacion()) output = true;
            return output;
        }

        public static bool operator ==(Dolar d1, Dolar d2)
        {
            bool output = false;
            if (d1.cantidad == d2.cantidad) output = true;
            return output;
        }



        public static Dolar operator -(Dolar d, Euro e)
        {
            Dolar output = new Dolar(d.GetCantidad() - (e.GetCantidad() / Euro.GetCotizacion()));
            return output;
        }
        public static Dolar operator -(Dolar d, Pesos p)
        {
            Dolar output = new Dolar(d.GetCantidad() - (p.GetCantidad() / Pesos.GetCotizacion()));
            return output;
        }

        public static Dolar operator +(Dolar d, Euro e)
        {
            Dolar output = new Dolar(d.GetCantidad() + (e.GetCantidad() / Euro.GetCotizacion()));
            return output;
        }

        public static Dolar operator +(Dolar d, Pesos p)
        {
            Dolar output = new Dolar(d.GetCantidad() + (p.GetCantidad() / Pesos.GetCotizacion()));
            return output;
        }
    }
}
