﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Moneda;


namespace Conversor_Dinero
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnConvertEuro_Click(object sender, EventArgs e)
        {
            //Euro euroConvert = new Euro(double.Parse(txtEuro.Text));
            //txtEuroAEuro.Text = euroConvert.GetCantidad().ToString();
        }
        

    }
}
