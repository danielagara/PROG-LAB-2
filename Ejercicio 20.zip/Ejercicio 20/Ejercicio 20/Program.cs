﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moneda;

namespace Ejercicio_20
{
    class Program
    {
        static void Main(string[] args)
        {
            Euro juan = new Euro(20);
            Dolar pepe = new Dolar(0);

            pepe = (Dolar)juan;

            Console.WriteLine("Ahora pepe tiene: {0:0.00}", pepe.GetCantidad());
            Console.ReadKey();


        }
    }
}
