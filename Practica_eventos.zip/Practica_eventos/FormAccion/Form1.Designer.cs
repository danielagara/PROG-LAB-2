﻿namespace FormAccion
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnMostrarTexto = new System.Windows.Forms.Button();
            this.btnIngresaTexto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnMostrarTexto
            // 
            this.btnMostrarTexto.Location = new System.Drawing.Point(55, 50);
            this.btnMostrarTexto.Name = "btnMostrarTexto";
            this.btnMostrarTexto.Size = new System.Drawing.Size(155, 63);
            this.btnMostrarTexto.TabIndex = 0;
            this.btnMostrarTexto.Text = "Mostrar texto";
            this.btnMostrarTexto.UseVisualStyleBackColor = true;
            // 
            // btnIngresaTexto
            // 
            this.btnIngresaTexto.Location = new System.Drawing.Point(55, 147);
            this.btnIngresaTexto.Name = "btnIngresaTexto";
            this.btnIngresaTexto.Size = new System.Drawing.Size(155, 63);
            this.btnIngresaTexto.TabIndex = 1;
            this.btnIngresaTexto.Text = "Ingrese texto";
            this.btnIngresaTexto.UseVisualStyleBackColor = true;
            this.btnIngresaTexto.Click += new System.EventHandler(this.btnIngresaTexto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnIngresaTexto);
            this.Controls.Add(this.btnMostrarTexto);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnMostrarTexto;
        private System.Windows.Forms.Button btnIngresaTexto;
    }
}

