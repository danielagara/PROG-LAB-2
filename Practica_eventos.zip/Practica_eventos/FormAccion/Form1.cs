﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FormAccion
{
    public delegate void delegado1(string texto);

    public partial class Form1 : Form
    {
        public event delegado1 enviarMensaje;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnIngresaTexto_Click(object sender, EventArgs e)
        {
            //PREGUNTAR MDPARENT, CHILD Y NO SE Q MAS 
            FormIngreseTexto.chil
            enviarMensaje.Invoke(this
        }
    }
}
