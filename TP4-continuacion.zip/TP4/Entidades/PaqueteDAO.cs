﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class PaqueteDAO
    {
        #region Atributos
        
        static private SqlCommand comando;
        static private SqlConnection conexion;
        
        #endregion

        #region Constructores

        static PaqueteDAO()
        {
            this.conexion = new SqlConnection(Entidades.Properties.Settings.Default.CadenaConexion);
        }

        #endregion

        #region Metodos

        public static bool Insertar(Paquete p)
        {
            try
            {
                
            }
            catch (SqlException et)
            {
                MessageBox.Show(et.Message);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            finally
            {
                cn.Close();
            }
        }

        #endregion
    }
}
