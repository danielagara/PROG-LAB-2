﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
    class Punto
    {
        private int x;
        private int y;
    }

    class Rectangulo
    {
        public float area;
        public float perimetro;
        Punto vertice1 = new Punto();
        Punto vertice2 = new Punto();
        Punto vertice3 = new Punto();
        Punto vertice4 = new Punto();

        public Rectangulo(Punto vertice1, Punto vertice3)
        {
            this.vertice1 = vertice1;
            this.vertice3 = vertice3;

        }

    }
}
