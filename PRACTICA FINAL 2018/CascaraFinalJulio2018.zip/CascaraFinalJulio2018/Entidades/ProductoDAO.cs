﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Data.SqlClient;

//namespace Entidades
//{
//    public class ProductoDAO
//    {
//        string cadenaDeConexion;
//        static SqlConnection conexion;
//        static SqlCommand comando;

//        static ProductoDAO()
//        {
//            comando = new SqlCommand();
//            conexion = new SqlConnection(Entidades.Properties.Settings.Default.CadenaConexion);
//        }

//        public bool GuardarProducto(Producto p)
//        {
//            //this.conexion = new SqlConnection();
//            comando.Connection = conexion;
//            comando.CommandType = System.Data.CommandType.Text;
//            string xQuery = "";
//            /*string descripcion = p.Descripcion;
//            char tipo;
//            int diametro; 
//            string material = null;
//            int largo;
//            int alto;
//            int ancho;*/
//            if (p is ProductoA)
//                xQuery = String.Format("INSERT INTO Productos VALUES {0}, {1}, {2}, {3}, {4}, {5}, {6}", p.Descripcion, 'A', ((ProductoA)p).Diametro, ((ProductoA)p).Material.ToString(), null, null, null);
//            if (p is ProductoB)
//                xQuery = String.Format("INSERT INTO Productos VALUES {0}, {1}, {2}, {3}, {4}, {5}, {6}", p.Descripcion, 'B', null, null, ((ProductoB)p).Alto, ((ProductoB)p).Largo, ((ProductoB)p).Ancho);
//            comando.CommandText = xQuery;
//            try
//            {
//                conexion.Open();
//                comando.ExecuteNonQuery();
//                //SqlDataReader xSqlDR = commando.ExecuteReader();
//                //xResult = xSqlDR[0].ToString() + " - " + xSqlDR[1].ToString();

//            }
//            catch (SqlException sqlE)
//            {

//                throw sqlE;
//            }
//            catch (Exception e)
//            {
//                throw e;
//            }
//            finally
//            {
//                conexion.Close();
//            }
//            return true;
//        }

//        public List<Producto> ObtenerProductos()
//        {
//            List<Producto> lstProductos = new List<Producto>();
//            try
//            {
//                this.conexion = new SqlConnection();
//                this.comando = new SqlCommand();
//                this.cadenaDeConexion = Properties.Settings.Default.ConectionString;
//                this.conexion.ConnectionString = this.cadenaDeConexion;
//                this.comando.Connection = conexion;
//                this.comando.CommandType = System.Data.CommandType.Text;
//                this.comando.CommandText = String.Format("SELECT * FROM Productos");
//                SqlDataReader xSqlDR = this.comando.ExecuteReader();
//                while (xSqlDR.Read())
//                {
//                    if (xSqlDR[2].ToString() == "A")
//                    {
//                        Producto prodA = new ProductoA(xSqlDR[2].ToString(), (short)xSqlDR[3], (Material)xSqlDR[4]);
//                        lstProductos.Add(prodA);
//                    }
//                    //xResult = xSqlDR[0].ToString() + " - " + xSqlDR[1].ToString();
//                    //cmbProvincias.Items.Add(xSqlDR[0].ToString());
//                    //Equipo eq = new Equipo((int)(xSqlDR[0]), xSqlDR[1].ToString());
//                    //xGrupo.Equipos.Add(eq);

//                }
//                xSqlDR.Close();

//            }
//            catch (SqlException sqlE)
//            {

//                throw sqlE;
//            }
//            catch (Exception e)
//            {
//                throw e;
//            }
//            finally
//            {
//                conexion.Close();
//            }

//            return lstProductos;

//        }
//    }
//}
