﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class ProductoB: Producto
    {
        #region Atributos

        private short alto;
        private short ancho;
        private short largo;

        #endregion

        #region Propiedades

        public short Alto
        {
            get
            {
                return this.alto;
            }
        }

        public short Ancho
        {
            get
            {
                return this.ancho;
            }
        }

        public short Largo
        {
            get
            {
                return this.largo;
            }
        }

        #endregion

        #region Constructores
        public ProductoB()
        {
 
        }

        public ProductoB(string descripcion, short largo, short alto, short ancho)
        :base(descripcion)
        {
            this.largo = largo;
            this.alto = alto;
            this.ancho = ancho;
        }

        #endregion

        #region Metodos
        public override string Mostrar()
        {
            string retorno = String.Format("Descripción producto: {0}, Alto: {1}, Ancho: {2}, Largo: {3}, Volumen: {4}", this.Descripcion, this.Alto.ToString(), this.Ancho.ToString(), this.Largo.ToString(), this.CalcularVolumen().ToString());
            return "";
        }

        private int CalcularVolumen()
        {
            int retorno=0;
            retorno= this.Largo*this.Alto*this.Ancho;
            return retorno;
        }

        public bool ValidarDimensiones()
        {
            bool retorno = false;

            int resultado = this.Alto + this.Ancho + this.Largo;

            if (resultado <= 100)
            {
                retorno = true;
            }

            return retorno;
        }
        #endregion
    }
}
