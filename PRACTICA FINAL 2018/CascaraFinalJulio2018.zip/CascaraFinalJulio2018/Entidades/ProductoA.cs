﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;


namespace Entidades
{
    public enum Material
    {
        Plastico,
        Aluminio,
        Caucho
    }

    public class ProductoA : Producto
    {
        #region Atributos

        private short diametro;

        private Material material;

        #endregion

        #region Propiedades

        public short Diametro
        {
            get
            {
                return this.diametro;
            }
        }

        public Material Material
        {
            get
            {
                return this.material;
            }

            set
            {
                if (this.ValidarMaterial() == true)
                {
                    this.material = value;
                }
                else
                {
                    string mensaje = String.Format("No se puede fabricar una pieza de {0} y diámetro de {1} centímetros.", value.ToString(), this.Diametro.ToString());
                    throw new MaterialException(mensaje);//revisar
                }
            }
        }
        #endregion

        #region Constructores

        public ProductoA()
        {
 
        }

        public ProductoA(string descripcion, short diametro, Material material)
        :base(descripcion)
        {
            this.material = material;
            this.diametro = diametro;
            
        }

        #endregion

        #region Metodos

        public override string Mostrar()
        {
            string retorno = String.Format("Descripción producto: {0}, Diámetro: {1}, Material: {2}", this.Descripcion, this.Diametro.ToString(), this.Material.ToString());
            return retorno;
        }

        public bool ValidarDimensiones()
        {
            bool retorno = false;

            if (this.Diametro % 2 == 0)
            {
                if (this.Diametro >= 30 && this.Diametro <= 50)
                {
                    retorno = true;
                }
            }

            return retorno;
        }

        public bool ValidarMaterial()
        {
            bool retorno = false;
            switch (this.Material)
            {
                case Entidades.Material.Aluminio:
                    if (this.Diametro <= 10)
                    {
                        retorno = true;
                    }
                    break;

                case Entidades.Material.Caucho:
                    if (this.Diametro <= 15)
                    {
                        retorno = true;
                    }
                    break;

                case Entidades.Material.Plastico:
                    retorno = true;
                    break;
            }
            return retorno;
        }

        #endregion
    }
}
