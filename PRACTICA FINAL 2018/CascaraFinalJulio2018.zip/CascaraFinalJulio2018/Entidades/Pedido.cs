﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Pedido
    {
        #region Atributos

        private List<Producto> productos;
        
        #endregion

        #region Propiedades

        public List<Producto> Productos
        {
            get
            {
                return this.productos;
            }
        }

        #endregion

        #region Constructores

        public Pedido()
        {
            this.productos = new List<Producto>();
        }

        #endregion

        #region Metodos
        public void FabricarPedido()
        {
            for (int i = 0; i < this.Productos.Count; i++)
            {
                //revisar
                System.Threading.Thread.Sleep(1000);
            }
        }
        #endregion

        #region Operadores
        public static Pedido operator +(Pedido unPedido, Producto unProducto)
        {
            if (unPedido.Productos.Count < 5)
            {
                if (unProducto is ProductoB)
                {
                    if (((ProductoB)unProducto).ValidarDimensiones())
                    {
                        unPedido.Productos.Add(unProducto);
                    }
                }
                else if(unProducto is ProductoA)
                {
                    unPedido.Productos.Add(unProducto);
                }
            }//revisar
            return unPedido;
        }

        #endregion
    }
}
