﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{

    public abstract class Producto
    {
        #region Atributos

        private string descripcion;

        #endregion 

        #region Delegados y Eventos

        public delegate void ProductoTerminado(object sender, EventArgs e);

        public event ProductoTerminado InformarProductoTerminado;

        #endregion

        #region Constructores

        public Producto()
        {
 
        }

        public Producto(string descripcion)
        {
            this.descripcion = descripcion;
        }

        #endregion

        #region Propiedades

        public string Descripcion
        {
            get
            {
                return this.descripcion;
            }
        }

        #endregion

        #region Metodos

        public void Elaborar()
        {
            //guarda en la base de datos el prod y lanza el evento informandolo
        }

        public virtual string Mostrar()
        {
            string retorno = String.Format("Descripción porducto: {0}", this.Descripcion);
            return retorno;
        }

        

        #endregion 

        
    }
}
