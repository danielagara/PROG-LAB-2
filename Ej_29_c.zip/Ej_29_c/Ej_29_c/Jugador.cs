﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_29_c
{
    public class Jugador
    {
        private long dni;
        private string nombre;
        private int partidosJugados;
        private float promedioGoles;
        private int totalGoles;

        private Jugador()
        {

            this.promedioGoles = 0;

        }

        public Jugador(string nombre, int totalGoles, int partidosJugados, long dni)
        :this(nombre)
        {
            
            this.totalGoles = totalGoles;
            this.partidosJugados = partidosJugados;
            this.dni = dni;
        }

        public Jugador(string nombre)
        {
            this.nombre = nombre;
        }

        public float GetPromedioGoles()
        {
            this.promedioGoles=(float)this.totalGoles / (float)this.partidosJugados;
            return this.promedioGoles;
        }

        public string MostrarDatos()
        {
            StringBuilder mysb = new StringBuilder();
            mysb.AppendLine("NOMBRE: "+this.nombre);
            mysb.AppendLine("DNI: "+this.dni.ToString());
            mysb.AppendLine("PARTIDOS JUGADOS: " + this.partidosJugados.ToString());
            mysb.AppendLine("TOTAL GOLES: " + this.totalGoles.ToString());
            mysb.AppendLine("PROMEDIO GOLES: " + this.promedioGoles.ToString());
            return mysb.ToString();
        }

        static public bool operator ==(Jugador j1, Jugador j2)
        {
            bool retorno = false;
            if (j1.dni == j2.dni)
            {
                retorno = true;
            }
            return retorno;
        }
        static public bool operator !=(Jugador j1, Jugador j2)
        {
            bool retorno = false;
            if (j1.dni != j2.dni)
            {
                retorno = true;
            }
            return retorno;
        }
    }
}
