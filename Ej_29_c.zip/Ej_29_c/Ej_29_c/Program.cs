﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_29_c
{
    class Program
    {
        static void Main(string[] args)
        {
            Jugador jugador1 = new Jugador("Franco", 50, 5, 41063474);
            Jugador jugador2 = new Jugador("Agustin", 40, 55, 41063484);

            Equipo equipo = new Equipo(5, "Rojo");

            float a= jugador1.GetPromedioGoles();
            
            float b= jugador2.GetPromedioGoles();

            if (equipo + jugador1)
            {
                if (equipo + jugador2)
                {
                    Console.WriteLine(jugador1.MostrarDatos());
                    Console.WriteLine(jugador2.MostrarDatos());
                }
            }

            Console.ReadKey();
        }
    }
}
