﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Ej_60
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //SqlConnection conexion = new SqlConnection(Properties.Settings.Default.connection);
            //SqlCommand comando = new SqlCommand("select * from Production.Product", conexion);
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            SqlConnection conexion = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=AdventureWorks2012;Integrated Security=True"); 
            //(Properties.Settings.Default.connection);
                //ConfigurationManager.ConnectionStrings["Ej_60.Properties.Settings.conn"].ConnectionString);
            //String connectionStr = @"Data Source=.\sqlexpress;Initial Catalog=AdventureWorks2012;Integrated Security=True";

            SqlCommand comando = new SqlCommand();
            comando.CommandText = "select * from Production.Product";
            comando.Connection = conexion;

            conexion.Open();

            SqlDataReader oDr = comando.ExecuteReader();

            while(oDr.Read())
            {
                comboBox1.Items.Add(oDr[1].ToString());

            }
            conexion.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //no agrega
            SqlConnection conexion = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=AdventureWorks2012;Integrated Security=True");
            SqlCommand comando = new SqlCommand("INSERT INTO Production.Product VALUES ('My DONE Field', 'DG-0108', 0 , 0 , NULL, 1000 , 750, 0 , 0, NULL, NULL, NULL, NULL , 0, NULL , NULL, NULL, NULL, NULL , 2008-04-30, NULL, NULL , '694215B7-08F7-AD0D-ACB1-D734BA44C0C4', 2014-02-08)", conexion);
            conexion.Close();

        }

        /*private void button3_Click(object sender, EventArgs e)
        {
            //elimina revisar
            SqlConnection conexion = new SqlConnection(@"Data Source=.\sqlexpress;Initial Catalog=AdventureWorks2012;Integrated Security=True");
            string productNumber= textBox1.Text;

            string cmm = "DELETE FROM Production.Product WHERE ProductNumber = '" + productNumber + "'";
            SqlCommand comando= new SqlCommand(cmm, conexion);
            conexion.Close();

        }*/

    }
}
