﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_clase5_c
{
    class Producto
    {
        private string codigoDeBarra;
        private string marca;
        private float precio;

        public Producto(string marca, string codigo, float precio)
        {
            this.codigoDeBarra = codigo;
            this.marca = marca;
            this.precio = precio;
        }

        public string GetMarca()
        {
            return this.marca;
        }

        public float GetPrecio()
        {
            return this.precio;
        }

        public string MostrarProducto(Producto producto)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(producto.codigoDeBarra);
            sb.AppendLine(producto.GetMarca());
            sb.AppendLine(producto.GetPrecio().ToString());
            return sb.ToString();
        }

        public static explicit operator string(Producto producto)
        {
            return producto.codigoDeBarra;
        }

        public static bool operator ==(Producto producto1, Producto producto2)
        {
            bool retorno = false;
            if ((string)producto1== (string)producto2)
            {
                if (producto1.GetMarca() == producto2.GetMarca())
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Producto producto1, Producto producto2)
        {
            bool retorno = false;
            if ((string)producto1 != (string)producto2)
            {
                if (producto1.GetMarca() != producto2.GetMarca())
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator ==(Producto producto, string marca)
        {
            bool retorno=false;
            if (producto.GetMarca() == marca)
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Producto producto, string marca)
        {
            bool retorno = false;
            if (producto.GetMarca() != marca)
            {
                retorno = true;
            }

            return retorno;
        }
    }
}
