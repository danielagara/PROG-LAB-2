﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_clase5_c
{
    class Estante
    {
        private Producto[] productos;
        private int ubicacionEstante;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }

        public Estante(int capacidad, int ubicacion)
            :this(capacidad)
        {
            this.ubicacionEstante = ubicacion;
        }

        public Producto[] GetProductos()
        {
            return this.productos;
        }

        public string MostrarEstante(Estante estante)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(estante.ubicacionEstante.ToString());
            for (int i = 0; i < estante.productos.Length; i++)
            {
                if (!object.ReferenceEquals(estante.productos[i], null))
                {
                    sb.AppendLine(estante.productos[i].MostrarProducto(productos[i]));
                }
                                
            }
            return sb.ToString();
        }

        public static bool operator ==(Estante estante, Producto producto)
        {
            bool retorno = false;
            for (int i = 0; i < estante.productos.Length; i++)
            {
                if (estante.productos[i] == producto)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator !=(Estante estante, Producto producto)
        {
            bool retorno = false;
            for (int i = 0; i < estante.productos.Length; i++)
            {
                if (estante.productos[i] != producto)
                {
                    retorno = true;
                }
            }
            return retorno;
        }

        public static bool operator +(Estante estante, Producto producto) //revisar
        {
            bool retorno = false;
            for (int i = 0; i < estante.productos.Length; i++)
            {
                if (object.ReferenceEquals(estante.productos[i], null))
                {
                    estante.productos[i] = producto;
                    retorno = true;
                    break;
                }
                else if(estante.productos[i] == producto)
                {
                    break;
                }
                
            }
            return retorno;
        }

        public static Estante operator -(Estante estante, Producto producto)
        {
            for (int i = 0; i < estante.productos.Length; i++)
            {
                if (estante.productos[i] == producto)
                {
                    estante.productos[i] = null;
                }
            }
            return estante;
        }
    }
}
