﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        string apellido;
        int legajo;
        string nombre;
    }

    void CalcularFinal()
    {
        
    }

    void Estudiar(byte nota1, byte nota2)
    {
        
    }

    void Mostrar()
    {
        
    }
}
