﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_37
{
    class Provincial : Llamada
    {
        Franja _franjaHoraria;

        public Provincial(Franja miFranja, Llamada llamada):this(llamada.NroOrigen, llamada.NroDestino, llamada.Duracion, miFranja)
        {

        }

        public Provincial(string origen, string destino, float duracion, Franja miFranja): base(duracion, destino, origen)
        {
            this._franjaHoraria = miFranja;
        }

        public enum Franja
        {
            Franja_1=0.99,
            Franja_2=1.25,
            Franja_3=0.66
        }


    }
}
