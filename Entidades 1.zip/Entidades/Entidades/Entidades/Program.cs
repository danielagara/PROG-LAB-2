﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Program
    {
        static void Main(string[] args)
        {
            Numero numero1 = new Numero();
            Numero numero2 = new Numero();
            Calculadora miCalculadora = new Calculadora();
            string operador;
            double resultado;

            Console.WriteLine("Ingrese el operador");
            operador=Console.ReadLine();
            resultado=miCalculadora.Operar(numero1, numero2, operador);
            Console.WriteLine("EL RESULTADO DE LA OPERACION ES : {0}", resultado);

            Console.ReadKey();
        }
    }
}
