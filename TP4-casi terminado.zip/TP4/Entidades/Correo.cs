﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Correo
    {
        #region Atributos
        
        private List<Thread> mockPaquetes;//se hace para tener una ref de cada thread

        private List<Paquete> paquetes;
        
        #endregion

        #region Constructores

        public Correo()
        {
            this.mockPaquetes= new List<Thread>();
            this.paquetes = new List<Paquete>();
        }

        #endregion

        #region Propiedades

        public List<Paquete> Paquetes
        {
            get
            {
                return this.paquetes;
            }

            set
            {
                this.paquetes = value;
            }
        }


        #endregion

        #region Metodos

        public void FinEntregas()
        {
            for (int i = 0; i < this.mockPaquetes.Count; i++)
            {
                this.mockPaquetes[i].Abort();
            }
        }

        public string MostrarDatos(IMostrar<List<Paquete>> elementos)
        {
            StringBuilder mysb = new StringBuilder();
            foreach (Paquete paq in ((Correo)elementos).Paquetes)
            {
                mysb.Append(paq.ToString());
                switch (paq.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        mysb.AppendLine(" Ingresado");
                        break;
                    case Paquete.EEstado.EnViaje:
                        mysb.AppendLine(" En Viaje");
                        break;
                    case Paquete.EEstado.Entregado:
                        mysb.AppendLine(" Entregado");
                        break;
                }
            }
            return mysb.ToString();
        }

        public static Correo operator +(Correo c, Paquete p)
        {
            bool flag = false;
            for (int i = 0; i < c.paquetes.Count; i++)
            {
                if ((Paquete)c.paquetes[i] == p)
                {
                    throw new TrackingIdRepetidoException("ID de tracking repetido");
                    flag = true;
                    break;
                }
                else if ((Paquete)c.paquetes[i] != p)
                {
                    flag = false;
                }
            }

            if (flag == false)
            {
                c.paquetes.Add(p);
                Thread mockThread = new Thread(p.MockCicloDeVida);
                mockThread.Start();
                c.mockPaquetes.Add(mockThread);
            }

            return c;
        }

        #endregion
    }
}
