﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Entidades
{
    public static class GuardaString
    {
        //tiene que ser de extension
        public static bool Guardar(this string texto, string archivo)
        {
            StreamWriter myStw = null;
            StringBuilder rutaArchivo = new StringBuilder();
            rutaArchivo.Append('@' + '"' + "Desktop" + '/' + archivo);//preguntar por la barra invertida
            myStw = new StreamWriter(rutaArchivo.ToString(), true);
            myStw.WriteLine(texto);
            myStw.Close();
            return true;
        }
    }
}
