﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public static class PaqueteDAO
    {
        #region Atributos
        
        static private SqlCommand comando;
        static private SqlConnection conexion;
        
        #endregion

        #region Constructores

        static PaqueteDAO()
        {
            conexion = new SqlConnection(Entidades.Properties.Settings.Default.CadenaConexion);
        }

        #endregion

        #region Metodos

        public static bool Insertar(Paquete p)
        {
            bool retorno = false;
            try
            {
                
            }
            catch (SqlException et)
            {
                //MessageBox.Show(et.Message);//ver esto q onda
            }
            catch (Exception ee)
            {
                //MessageBox.Show(ee.Message);
            }
            finally
            {
                conexion.Close();
                retorno = true;
            }

            return retorno;
        }

        #endregion
    }
}
