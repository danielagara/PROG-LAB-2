﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_2
{
    class Program
    {
        /// <summary>
        /// Conversor de Binario ASCII a Entero y biceversa
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Clase 2";
            int key;
            int keyUs;
            bool continuar = true;
            string valor;
            string usuario;
            

                    Calculador calculadorUsUno = new Calculador("Usuario 1");
                    Calculador calculadorUsDos = new Calculador("Usuario 2");
                    Calculador calculadorUsTres = new Calculador("Usuario 3");
            //Calculador miCalculador = new Calculador(usuario);
            //Console.WriteLine("NUM USUARIO {0}", miCalculador.usuario);

            do
            {
                // Menú
                Console.ForegroundColor = ConsoleColor.Gray;
                Console.WriteLine("1 - Convertir de Binario a Entero");
                Console.WriteLine("2 - Convertir de Entero a Binario");
                Console.WriteLine("3 - Resultado del calculo en Entero");
                Console.WriteLine("4 - Resultado del calculo en Binario");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("5 - Salir");
                Console.ForegroundColor = ConsoleColor.White;
                // Fin Menú

                // Si el valor ingresa por el usuario NO es válido, fuerzo la iteración,
                // salteando el código que está por debajo
                if(!int.TryParse(Console.ReadKey().KeyChar.ToString(), out key))
                    continue;
                Console.WriteLine("");
                // Según la tecla presionada por el usuario...
                switch(key)
                {
                    case 1:
                        Console.WriteLine("Ingrese un valor Binario ASCII a convertir a Entero: ");
                        valor= Console.ReadLine();
                        Conversor.BinarioEntero(valor);
                        Console.WriteLine("QUE USUARIO SOS?");
                        usuario = Console.ReadLine();
                        keyUs = int.Parse(usuario);
                        switch (keyUs)
                        {
                            case 1:
                                calculadorUsUno.acumular(valor);
                                break;
                            case 2:
                                calculadorUsDos.acumular(valor);
                                break;
                            case 3:
                                calculadorUsTres.acumular(valor);
                                break;
                        }
                        Console.ReadKey();
                        break;
                    case 2:
                        Console.WriteLine("Ingrese un valor Entero a convertir a Binario ASCII: ");
                        int converso;
                        if (int.TryParse(Console.ReadLine(), out converso))
                            Console.WriteLine(Conversor.EnteroBinario(converso));
                        else
                            Console.WriteLine("¡Valor inválido!");
                        Console.ReadKey();
                        break;

                    case 3:
                        Console.WriteLine("Resultado del acumulador en entero");
                        //Console.WriteLine("EL RESULTADO ES {0}", miCalculador.getResultadoEntero());
                        Console.ReadKey();
                        break;
                    
                    case 4:
                        Console.WriteLine("Resultado del acumulador en binario");
                        //Console.WriteLine("EL RESULTADO ES {0}", miCalculador.getResultadoBinario());
                        Console.ReadKey();
                        break;
                    case 5:
                        continuar = false;
                        break;
                }
                Console.Clear();
            } while(continuar);

            Console.WriteLine("EL RESULTADO DEL ACUMULADOR EN {0} ES {1}", calculadorUsUno.usuario,calculadorUsUno.getResultadoEntero());
            Console.WriteLine("EL RESULTADO DEL ACUMULADOR EN {0} ES {1}", calculadorUsDos.usuario, calculadorUsDos.getResultadoEntero());
            Console.WriteLine("EL RESULTADO DEL ACUMULADOR EN {0} ES {1}", calculadorUsTres.usuario, calculadorUsTres.getResultadoEntero());
            Console.ReadKey();
        }

        /// <summary>
        /// Si compro 3 o más camisas, deberá retornar un descuento del 20%.
        /// Sino, el descuento será del 10%.
        /// Documentar cada método, estructura repetitiva y cualquier parte del código
        /// que su lectura pudiera prestarse a confusión, según estándares dados en clase
        /// (https://msdn.microsoft.com/es-es/library/ff926074.aspx).
        /// </summary>
        /// <param name="precio">Valor de las camisas</param>
        /// <param name="camisas">Cantidad de camisas</param>
        /// <returns></returns>
        private static string documentame(float precio, int camisas)
        {
            if (camisas >= 3)
            {
                // Calcular descuento del 20%
                float a = (precio * 20) / 100;
                // Aplicar descuento
                float b = precio - a;
                return "DESCUENTO 20% PRECIO ES:  " + b;
            }
            else
            {
                // Calcular descuento del 10%
                float a = (precio * 10) / 100;
                // Aplicar descuento
                float b = precio - a;
                return "DESCUENTO 10% PRECIO ES:  " + b;
            }
        }
    }
}
