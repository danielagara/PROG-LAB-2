﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garat.Daniela._2D
{
    abstract public class Mascota
    {
        #region Atributos
        
        private string nombre;
        private string raza;
        
        #endregion

        #region Constructores

        public Mascota(string nombre, string raza)
        {
            this.nombre = nombre;
            this.raza = raza;
        }

        #endregion

        #region Propiedades

        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }

        public string Raza
        {
            get
            {
                return this.raza;
            }
        }

        #endregion

        #region Metodos

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        abstract protected string Ficha();

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        protected virtual string DatosCompletos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(this.Nombre + this.Raza);

            //falta el formato
            return sb.ToString();
        }
        #endregion

    }
}
