﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garat.Daniela._2D
{
    class Program
    {
        static void Main(string[] args)
        {

            Perro perro1 = new Perro("fluffy", "siberiano", 7, true);
            Gato gato1 = new Gato("muffin", "ndjnd");

            Perro perro2 = new Perro("coco", "golden");

            Grupo grupo = new Grupo("manada1", Grupo.TipoManada.Mixta);

            grupo = grupo + perro1;
            grupo = grupo + perro2;
            grupo = grupo + gato1;
            grupo = grupo + perro1;

            Console.WriteLine(grupo);


            Console.WriteLine("SIN EL 1");

            grupo = grupo - perro1;
            Console.WriteLine(grupo);

            Console.ReadKey();
        }
    }
}
