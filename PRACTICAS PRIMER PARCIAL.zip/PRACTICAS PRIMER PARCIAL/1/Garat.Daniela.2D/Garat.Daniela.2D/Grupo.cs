﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garat.Daniela._2D
{
    public class Grupo
    {
        #region Atributos

        private List<Mascota> manada;
        private string nombre;
        private TipoManada tipo;

        #endregion

        #region Constructores
        /*static Grupo()
        {
            //Grupo.tipo= TipoManada.Unica;
        }*/

        private Grupo()
        {
            this.manada=new List<Mascota>();
        }

        public Grupo(string nombre)
            :this()
        {
            this.nombre = nombre;
        }

        public Grupo(string nombre, TipoManada tipoMan)
            :this(nombre)
        {
            this.tipo= tipoMan;
        }
        #endregion

        #region Propiedades
        public TipoManada Tipo
        {
            set
            {
                tipo = value;
            }
        }

        #endregion

        #region Operadores
        public static implicit operator string(Grupo grupo)
        {
            
            StringBuilder sb = new StringBuilder();
            
            sb.AppendFormat("**{0} {1}**\n", grupo.nombre, grupo.tipo);//ver
            sb.AppendLine("Integrantes: ");
            for (int i = 0; i < grupo.manada.Count; i++)
            {
                if (grupo.manada[i] is Gato)
                {
                    sb.AppendLine(((Gato)grupo.manada[i]).ToString());
                }
                else if (grupo.manada[i] is Perro)
                {
                    sb.AppendLine(((Perro)grupo.manada[i]).ToString());
                }
                //sb.AppendLine(grupo.manada[i].ToString());
            }

            return sb.ToString();
        }

        public static bool operator !=(Grupo grupo, Mascota mascota)
        {
            bool retorno = false;
            for (int i = 0; i < grupo.manada.Count; i++)
            {
                if ((grupo.manada[i] is Gato) && (mascota is Gato))
                {
                    if (grupo.manada.Equals((Gato)mascota))
                    {
                        retorno = false;
                    }
                }

                else if ((grupo.manada[i] is Perro) && (mascota is Perro))
                {
                    if(grupo.manada.Equals((Perro)mascota))
                    {
                        retorno=false;
                    }
                }
            }

            return retorno;
        }

        public static bool operator ==(Grupo grupo, Mascota mascota)
        {
            bool retorno = false;
            for (int i = 0; i < grupo.manada.Count; i++)
            {
                if ((grupo.manada[i] is Gato) && (mascota is Gato))
                {
                    if (grupo.manada.Equals((Gato)mascota))
                    {
                        retorno = true;
                        break;
                    }
                }

                else if ((grupo.manada[i] is Perro) && (mascota is Perro))
                {
                    if (grupo.manada.Equals((Perro)mascota))
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;
        }

        public static Grupo operator +(Grupo grupo, Mascota mascota)
        {
            if (!(grupo == mascota))
            {
                grupo.manada.Add(mascota);
            }

            return grupo;
        }


        public static Grupo operator -(Grupo grupo, Mascota mascota)
        {
            if (grupo == mascota)
            {
                grupo.manada.Remove(mascota);
            }

            return grupo;
        }

        #endregion

        public enum TipoManada
        {
            Unica,
            Mixta
        }
    }
}
