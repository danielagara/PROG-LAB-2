﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garat.Daniela._2D
{
    public class Gato : Mascota
    {
        #region Constructores

        public Gato(string nombre, string raza)
        :base(nombre, raza)
        {

        }

        #endregion

        #region Operadores

        public static bool operator ==(Gato gato1, Gato gato2)
        {
            bool retorno = false;
            if ((gato1.Nombre == gato2.Nombre) && (gato1.Raza == gato2.Raza))
            {
                retorno = true;
            }

            return retorno;
        }

        public static bool operator !=(Gato gato1, Gato gato2)
        {
            bool retorno = false;
            if ((gato1.Nombre != gato2.Nombre) && (gato1.Raza != gato2.Raza))
            {
                retorno = true;
            }

            return retorno;
        }

        #endregion

        #region Metodos

        protected override string Ficha()
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine(this.Nombre + " "+ this.Raza);

            return sb.ToString();
        }

        public override string ToString()
        {
            return this.Ficha();
        }

        public override bool Equals(object gato)
        {
            bool retorno = false;

            if ((Gato)gato == this)
            {
                retorno = true;
            }

            return retorno;
        }


        #endregion

    }
}
