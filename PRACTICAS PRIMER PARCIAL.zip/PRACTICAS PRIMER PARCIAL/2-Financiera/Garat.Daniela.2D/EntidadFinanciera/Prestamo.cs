﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrestamosPersonales
{
    public enum PeriodicidadDePagos : int
    {
        Mensual=25,
        Bimestral=35,
        Trimestral=40
    }

    public enum TipoDePrestamo
    {
        Pesos,
        Dolares,
        Todos
    }

    abstract public class Prestamo
    {
        #region Atributos
        protected float monto;
        protected DateTime vencimiento;
        #endregion

        #region Constructores
        public Prestamo(float monto, DateTime vencimiento)
        {
            this.monto = monto;
            this.vencimiento = vencimiento;
        }

        #endregion

        #region Propiedades

        public float Monto
        {
            get 
            {
                return this.monto; 
            }
        }

        public DateTime Vencimiento
        {
            get
            {
                return this.vencimiento;
            }

            set
            {
                DateTime actual= DateTime.Now;

                if (value > actual)
                {
                    this.vencimiento = value;
                }
                else
                {
                    this.vencimiento = actual;
                }
            }
        }
        
        #endregion

        #region Metodos

        public static int OrdenarPorFecha(Prestamo p1, Prestamo p2)
        {
            int retorno = 0;
            if (p1.Vencimiento > p2.Vencimiento)
            {
                retorno = 1;
            }
            else if (p2.Vencimiento > p1.Vencimiento)
            {
                retorno = -1;
            }

            if (p2.vencimiento == p1.vencimiento)
            {
                retorno = 0;
            }
            return retorno;
        }

        abstract public void ExtenderPlazo(DateTime nuevoVencimiento);

        public virtual string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Monto: " + this.Monto.ToString());
            sb.AppendFormat("Vencimiento: {0:yyyy/MM/dd}" , this.Vencimiento.ToString());

            return sb.ToString();
        }

        #endregion
    }
}
