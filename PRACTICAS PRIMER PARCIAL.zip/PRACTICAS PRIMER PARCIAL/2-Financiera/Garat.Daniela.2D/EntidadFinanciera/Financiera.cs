﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using PrestamosPersonales;

namespace EntidadFinanciera
{
    public class Financiera
    {
        #region Atributos
        
        private List<Prestamo> listaDePrestamos;
        private string razonSocial;
        
        #endregion

        #region Constructores
        public Financiera(string razonSocial)
            :this()
        {
            this.razonSocial = razonSocial;
        }

        private Financiera()
        {
            listaDePrestamos = new List<Prestamo>();
        }

        #endregion

        #region Propiedades

        public List<Prestamo> ListaDePrestamos
        {
            get
            {
                return this.listaDePrestamos;
            }
        }

        public string RazonSocial
        {
            get
            {
                return this.razonSocial;
            }
        }

        public float InteresesEnDolares
        {
            get
            {
                return this.CalcularInteresGanado(TipoDePrestamo.Dolares);
            }
        }

        public float InteresesEnPesos
        {
            get
            {
                return this.CalcularInteresGanado(TipoDePrestamo.Pesos);
            }
        }

        public float InteresesTotales
        {
            get
            {
                return this.CalcularInteresGanado(TipoDePrestamo.Todos);
            }
        }

        #endregion

        #region Metodos
        public void OrdenarPrestamos()
        {
            this.ListaDePrestamos.Sort(Prestamo.OrdenarPorFecha);
        }

        private float CalcularInteresGanado(TipoDePrestamo tipoPrestamo)
        {
            float acumulador = 0;
            for (int i = 0; i < this.ListaDePrestamos.Count; i++)
            {
                switch (tipoPrestamo)
                {
                    case TipoDePrestamo.Pesos:
                        if (this.listaDePrestamos[i] is PrestamoPesos)
                        {
                            acumulador = acumulador + ((PrestamoPesos)this.listaDePrestamos[i]).Interes;
                        }
                        break;

                    case TipoDePrestamo.Dolares:
                        if (this.listaDePrestamos[i] is PrestamoDolar)
                        {
                            acumulador = acumulador + ((PrestamoDolar)this.listaDePrestamos[i]).Interes;
                        }
                        break;

                    case TipoDePrestamo.Todos:
                        if (this.listaDePrestamos[i] is PrestamoPesos)
                        {
                            acumulador = acumulador + ((PrestamoPesos)this.listaDePrestamos[i]).Interes;
                        }
                        else if (this.listaDePrestamos[i] is PrestamoDolar)
                        {
                            acumulador = acumulador + ((PrestamoDolar)this.listaDePrestamos[i]).Interes;
                        }

                        break;

                }
            }

            return acumulador;
            
        }

        public static explicit operator string  (Financiera financiera)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Intereses totales: " + financiera.InteresesTotales.ToString());
            sb.AppendLine("Intereses dolares: " + financiera.InteresesEnDolares.ToString());
            sb.AppendLine("Intereses pesos: " + financiera.InteresesEnPesos.ToString());
            financiera.OrdenarPrestamos();

            foreach (Prestamo prest in financiera.ListaDePrestamos)
            {
                if (prest is PrestamoDolar)
                {
                    sb.AppendLine(((PrestamoDolar)prest).Mostrar());
                }

                if (prest is PrestamoPesos)
                {
                    sb.AppendLine(((PrestamoPesos)prest).Mostrar());
                }
            }

            return sb.ToString();
        }

        public static string Mostrar(Financiera financiera)
        {
            return (string)financiera;
        }

        public static bool operator !=(Financiera financiera, Prestamo prestamo)
        {
            bool retorno = true;
            foreach (Prestamo prest in financiera.ListaDePrestamos)
            {
                if (prest.Equals(prestamo))
                {
                    retorno = false;
                    break;
                }

            }
            return retorno;
        }

        public static bool operator ==(Financiera financiera, Prestamo prestamo)
        {
            return !(financiera != prestamo);
        }

        public static Financiera operator +(Financiera financiera, Prestamo prestamo)
        {
            if (financiera != prestamo)
            {
                financiera.ListaDePrestamos.Add(prestamo);
            }

            return financiera;
        }
        #endregion
    }
}
