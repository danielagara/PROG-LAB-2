﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PrestamosPersonales
{
    public class PrestamoPesos : Prestamo
    {
        private float porcentajeInteres;

        #region Constructores

        public PrestamoPesos(float monto, DateTime vencimiento, float interes)
        :base(monto, vencimiento)
        {
            this.porcentajeInteres = interes;
        }

        public PrestamoPesos(Prestamo prestamo, float porcentajeInteres)
        :this(prestamo.Monto, prestamo.Vencimiento, porcentajeInteres)
        {
 
        }
        #endregion

        #region Propiedades
        public float Interes
        {
            get
            {
                return this.CalcularInteres();
            }
        }

        #endregion

        #region Metodos

        private float CalcularInteres()
        {
            float retorno = 0;

            retorno = (base.Monto * this.porcentajeInteres)/100;

            return retorno;
        }

        public override void ExtenderPlazo(DateTime nuevoVencimiento)
        {
            int dias = (nuevoVencimiento - base.Vencimiento).Days;
            this.porcentajeInteres= this.porcentajeInteres + (dias * 0.25f);
            base.Vencimiento = nuevoVencimiento;
        }

        public override string Mostrar()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append(base.Mostrar());
            sb.AppendLine("Porcentaje interes: " + this.porcentajeInteres.ToString());
            sb.AppendLine("Interes: " + this.Interes.ToString());

            return sb.ToString();
        }
        #endregion
    }
}
