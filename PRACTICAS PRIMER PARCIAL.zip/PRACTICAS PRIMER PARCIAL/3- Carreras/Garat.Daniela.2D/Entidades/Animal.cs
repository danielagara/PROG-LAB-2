﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Animal
    {
        #region Atributos

        protected int _cantidadPatas;
        protected static Random _distanciaRecorrida;
        protected int _velocidadMaxima;

        #endregion

        #region Constructores
        /// <summary>
        /// constructor estatico 
        /// </summary>
        static Animal()
        {
            _distanciaRecorrida = new Random();
        }

        /// <summary>
        /// 
        /// </summary>
        public Animal(int cantidadPatas, int velocidadMaxima)
        {
            this._cantidadPatas = cantidadPatas;
            this._velocidadMaxima = velocidadMaxima;
        }
        #endregion

        #region Propiedades
        /// <summary>
        /// Get y set del atributo CantidadPatas, no puede ser mayor a 4
        /// </summary>
        public int CantidadPatas
        {
            get
            {
                return this._cantidadPatas;
            }

            set
            {
                if (value <= 4)
                {
                    this._cantidadPatas = value;
                }
                else
                {
                    this._cantidadPatas = 4;
                }
            }

        }

        /// <summary>
        /// Get y Set del atributo Velocidad maxima, no puede ser mayor a 60
        /// </summary>
        public int VelocidadMaxima
        {
            get
            {
                return this._velocidadMaxima;
            }

            set
            {
                if (value <= 60)
                {
                    this._velocidadMaxima = value;
                }
                else
                {
                    this._velocidadMaxima = 60;
                }
            }
        }

        /// <summary>
        /// get de DistanciaRecorrida, devuelve random entre 10 y la velocidadMaxima
        /// </summary>
        public int DistanciaRecorrida
        {
            get
            {
                Random random = new Random();
                return random.Next(10, this.VelocidadMaxima);
            }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// devuelve todos los datos de animal en una string
        /// </summary>
        public string Mostrar()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("CANTIDAD DE PATAS: " + this.CantidadPatas.ToString());
            sb.AppendLine("DISTANCIA RECORRIDA: " + this.DistanciaRecorrida.ToString());
            sb.AppendLine("VELOCIDAD MAXIMA: " + this.VelocidadMaxima.ToString());

            return sb.ToString();
        }

        #endregion
    }
}
