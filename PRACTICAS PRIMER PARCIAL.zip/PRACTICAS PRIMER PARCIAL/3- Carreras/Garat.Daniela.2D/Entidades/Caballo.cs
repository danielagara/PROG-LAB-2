﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Caballo : Animal
    {
        #region Atributos
        private static int _patas;
        private string _nombre;
        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        static Caballo()
        {
            _patas = 4;
        }

        /// <summary>
        /// 
        /// </summary>
        public Caballo(string nombre, int velocidadMaxima)
            :base(_patas,velocidadMaxima)
        {
            this._nombre = nombre;
        }
        #endregion

        #region Metodos
        /// <summary>
        /// 
        /// </summary>
        public string MostrarCaballo()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.Mostrar());
            sb.AppendLine("NOMBRE: " + this._nombre);

            return sb.ToString();
        }
        #endregion

        #region Operadores
        /// <summary>
        /// 
        /// </summary>
        public static bool operator !=(Caballo c1, Caballo c2)
        {
            bool retorno=false;
            if (c1._nombre == c2._nombre)
            {
                retorno = false;
            }
            else
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool operator ==(Caballo c1, Caballo c2)
        {
            bool retorno = false;
            if (c1._nombre == c2._nombre)
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }
        #endregion
    }
}
