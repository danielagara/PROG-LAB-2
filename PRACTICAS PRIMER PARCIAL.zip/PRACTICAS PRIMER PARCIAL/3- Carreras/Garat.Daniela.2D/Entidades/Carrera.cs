﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Carrera
    {
        private List<Animal> animales;
        private int _corredoresMax;

        private Carrera()
        {
            animales = new List<Animal>();
        }

        public Carrera(int corredoresMax)
            :this()
        {
            this._corredoresMax = corredoresMax;
        }

        public string MostrarCarrera(Carrera c)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("CORREDORES MAX: " + this._corredoresMax);
            for (int i = 0; i < this.animales.Count; i++)
            {
                if (this.animales[i] is Humano)
                {
                    sb.AppendLine(((Humano)this.animales[i]).MostrarHumano());
                }
                if (this.animales[i] is Perro)
                {
                    sb.AppendLine(((Perro)this.animales[i]).MostrarPerro());
                }
                if (this.animales[i] is Caballo)
                {
                    sb.AppendLine(((Caballo)this.animales[i]).MostrarCaballo());
                }
            }

            return sb.ToString();
        }
    }
}
