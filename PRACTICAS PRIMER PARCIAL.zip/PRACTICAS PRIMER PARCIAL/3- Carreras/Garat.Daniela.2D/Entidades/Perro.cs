﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Perro : Animal
    {
        #region Enumerado
        public enum Razas
        {
            Galgo,
            OvejeroAleman,
        }
        #endregion

        #region Atributos

        private static int _patas;
        private Razas _raza;

        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        static Perro()
        {
            _patas = 4;
        }

        /// <summary>
        /// 
        /// </summary>
        public Perro(int velocidadMaxima)
        :base(_patas,velocidadMaxima)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        public Perro(Razas raza, int velocidadMaxima)
        :this(velocidadMaxima)
        {
            this._raza = raza;
        }

        #endregion

        #region Metodos
        /// <summary>
        /// 
        /// </summary>
        public string MostrarPerro()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(this.Mostrar());
            sb.AppendLine("RAZA: " + this._raza.ToString());

            return sb.ToString();
        }
        #endregion

        #region Operadores
        /// <summary>
        /// 
        /// </summary>
        public static bool operator !=(Perro p1, Perro p2)
        {
            bool retorno = false;
            if ((p1._raza == p2._raza) && (p1.VelocidadMaxima == p2.VelocidadMaxima))
            {
                retorno = false;
            }
            else
            {
                retorno = true;
            }

            return retorno;
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool operator ==(Perro p1, Perro p2)
        {
            bool retorno = false;
            if ((p1._raza == p2._raza) && (p1.VelocidadMaxima == p2.VelocidadMaxima))
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }
        #endregion
    }
}
