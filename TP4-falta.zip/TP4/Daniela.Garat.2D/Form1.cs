﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;


namespace Daniela.Garat._2D
{
    public partial class Form1 : Form
    {
        Correo mycorreo = new Correo();

        public Form1()
        {
            InitializeComponent();   
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete nuevoPaquete = new Paquete(txtDireccion.Text, txtTrackingID.Text);
            nuevoPaquete.InformaEstado += paq_InformaEstado;
            this.mycorreo=this.mycorreo+nuevoPaquete;
            this.ActualizarEstados();
        }

        private void ActualizarEstados()
        {
            lst1.Text="";
            lst2.Text="";
            lst3.Text="";

            foreach (Paquete paq in mycorreo.Paquetes)
            {
                switch (paq.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        lst1.Items.Add(paq);
                        break;

                    case Paquete.EEstado.EnViaje:
                        lst1.Items.Remove(paq);
                        lst2.Items.Add(paq);
                        break;

                    case Paquete.EEstado.Entregado:
                        lst2.Items.Remove(paq);
                        if (!lst3.Items.Contains(paq))
                        {
                            lst3.Items.Add(paq);
                        }
                        break;
                }
            }
        }

        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke( d, new object[] {sender, e} );
            }
            else 
            {
                this.ActualizarEstados();
            }
        }

        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            //LA MIERDA ESTA NO FUNCIONA
            if(elemento.GetType() == typeof(Paquete))
            {
                rtbMostrar.Text=((Paquete)elemento).ToString();
                rtbMostrar.Text.Guardar("salida.txt");
            }
            if (elemento.GetType() == typeof(Correo))
            {
                List<Paquete> listaPaqs= new List<Paquete>();
                listaPaqs=((Correo)elemento).Paquetes;
                rtbMostrar.Text = ((Correo)elemento).MostrarDatos((IMostrar<List<Paquete>>)listaPaqs);
                rtbMostrar.Text.Guardar("salida.txt");
            }
             if(elemento.GetType() == typeof(List<Paquete>))
             {
                 foreach (Paquete paq in ((List<Paquete>)elemento))
                 {
                     rtbMostrar.Text = paq.ToString();
                     rtbMostrar.Text.Guardar("salida.txt");
                 }
             }
            
        }

        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            //NO SE PORQUE TIRA INVALID CAST EXCEPTION
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)mycorreo);
        }
    }
}
