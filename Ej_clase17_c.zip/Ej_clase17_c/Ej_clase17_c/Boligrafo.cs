﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_clase17_c
{
    class Boligrafo
    {
        short cantidadTintaMaxima;
        public ConsoleColor color;
        public short tinta;

        public Boligrafo()
        {
            this.cantidadTintaMaxima = 100;
        }

        public ConsoleColor GetColor()
        {
            return this.color;
        }

        public short GetTinta()
        {
            return this.tinta;
        }

        private void SetTinta(short tinta)
        {
            if (tinta < this.cantidadTintaMaxima)
            {
                this.tinta = tinta;
            }
        }

        public void Recargar()
        {
            this.SetTinta(this.cantidadTintaMaxima);
        }

        public bool Pintar(int gasto, out string dibujo)
        {
            StringBuilder sb = new StringBuilder();
            bool retorno = false;
            //char[] cadena= new char[this.cantidadTintaMaxima];

            if (gasto < this.tinta)
            {
                this.tinta = (short)(this.tinta - (short)gasto);
                if (this.tinta > 0)
                {
                    for (int i = 0; i < gasto; i++)
                    {
                        sb.Append("*");
                        //cadena[i] = '*';
                    }
                    retorno = true;
                }
            }
            else if (gasto > this.tinta && this.tinta > 0)
            {
                gasto=gasto - this.tinta;
                for (int j = 0; j < this.tinta ; j++)
                {
                    sb.Append("*");
                }
                retorno = false;

            }

            dibujo = sb.ToString();
            return retorno;
        }
    }
}
