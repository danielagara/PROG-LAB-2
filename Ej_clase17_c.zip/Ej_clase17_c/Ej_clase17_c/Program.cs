﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_clase17_c
{
    class Program
    {
        static void Main(string[] args)
        {
            string dibujo;

            Boligrafo boligrafoAzul = new Boligrafo();
            Boligrafo boligrafoRojo = new Boligrafo();

            boligrafoAzul.color = ConsoleColor.Blue;
            boligrafoAzul.tinta = 100;

            boligrafoRojo.color = ConsoleColor.Red;
            boligrafoRojo.tinta = 50;

            if (boligrafoAzul.Pintar(5, out dibujo) == true)
            {
                Console.BackgroundColor = boligrafoAzul.color;
                Console.WriteLine("DIBUJO  " + dibujo);
            }
            
            Console.ReadKey();
        }
    }
}
