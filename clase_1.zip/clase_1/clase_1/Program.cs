﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clase_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*string palabra = "holahola";
            Console.WriteLine("Hola Mundo {0}", palabra);
            Console.ReadLine();
            */
            List<int> nombres =new List<int>();
            nombres.Add(1);
            nombres.Add(2);
            nombres.Add(3);

            for (int i = 0; i < nombres.Count; i++)
            {
                if(i==0)
                {
                    nombres.Remove(nombres[0]);
                }
                int auxNum = nombres[i];
                Console.WriteLine(auxNum);
            }

            /*foreach(int auxNum in nombres)
            {
                nombres.Remove(nombres[0]);
                Console.WriteLine(auxNum);
                

            }*/

        }
    }
}
