﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Numero
    {
        private double numero;

        private double ValidarNumero(string strNumero)
        {
            double numero;
            bool validacion;
            if (!double.TryParse(strNumero, out numero))
            {
                numero = 0;
            }

            return numero;
        }

        public string BinarioDecimal(string binario)
        {
            string retorno="Valor invalido";


            return retorno;
        }
    }
}
