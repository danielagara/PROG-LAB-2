﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibCalcu;


namespace LaCaluladora
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)//funciona limpiar
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            lblResultado.Text = "0" ;
            cmbOperador.Text = " " ;
        }

        private void btnCerrar_Click(object sender, EventArgs e)//funciona cerrar
        {
            this.Close();
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            
        }
    }
}
