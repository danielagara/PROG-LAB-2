﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    class Numero
    {
        private double numero;

        /* SE HACE CON PROPERTIES
        public Numero(string strNumero)
            :this(ValidarNumero(strNumero))
        {
        }

        public Numero(double numero)
        {
            this.numero = numero;
        }*/
        
        private double ValidarNumero(string strNumero)
        {
            double numero;
            // bool validacion;
            if (!double.TryParse(strNumero, out numero))
            {
                numero = 0;
            }

            return numero;
        }

        public string BinarioDecimal(string binario)
        {
            string retorno = "Valor invalido";

            if (ValidarNumero(binario) != 0)
            {
                for (int i = 1; i <= binario.Length; i++)
                {
                    retorno += int.Parse(binario[i - 1].ToString()) * (int)Math.Pow(2, binario.Length - i);
                }
            }
            return retorno;
        }

        public string DecimalBinario(string numero)
        {
            string binario = "";
            int entero;
            if (ValidarNumero(numero) != 0)
            {
                entero = int.Parse(numero);
                while (entero > 0)
                {
                    binario = (entero % 2).ToString() + binario;
                    entero = entero / 2;
                }
            }
            else
            {
                binario="Valor invalido";
            }
            
            return binario;
        }

        public string DecimalBinario(double numero)
        {
            string retorno;
            retorno = DecimalBinario(numero.ToString());

            return retorno;
        }

        public static double operator +(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.numero + n2.numero;
            return retorno;
        }

        public static double operator *(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.numero * n2.numero;
            return retorno;
        }

        public static double operator /(Numero n1, Numero n2)
        {
            double retorno=0;
            if (n1.numero > 0)
            {
                retorno = n1.numero / n2.numero;
            }
            return retorno;
        }

        public static double operator -(Numero n1, Numero n2)
        {
            double retorno;
            retorno = n1.numero - n2.numero;
            return retorno;
        }

    }
}
