﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_52
{
    public class Lapiz : IAcciones
    {
        private float tamanioMina;

        public Lapiz(int unidades)
        {
            this.tamanioMina = unidades;
        }

        public ConsoleColor Color
        {
            get
            {
                return ConsoleColor.Gray;
            }

            set
            {
                throw new NotImplementedException();
            }
        }

        public float UnidadesDeEscritura
        {
            get
            {
                return this.tamanioMina;
            }

            set
            {
                this.tamanioMina = value;
            }
        }

        public EscrituraWrapper Escribir(string texto)
        {
            for (int i = 0; i < texto.Length; i++)
            {
                this.UnidadesDeEscritura = this.UnidadesDeEscritura - 0.1f;
            }

            EscrituraWrapper escritura = new EscrituraWrapper(texto, this.Color);

            return escritura; 
        }

        public bool Recargar(int unidades)
        {
            throw new NotImplementedException();
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Lapiz");
            sb.AppendLine(this.Color.ToString());
            sb.AppendLine(this.UnidadesDeEscritura.ToString());

            return sb.ToString();
        }

    }
}
