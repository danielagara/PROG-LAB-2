﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_16_c
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno alumnoUno = new Alumno();
            Alumno alumnoDos = new Alumno();
            Alumno alumnoTres = new Alumno();

            alumnoUno.nombre = "Ana";
            alumnoDos.nombre = "Pepe";
            alumnoTres.nombre = "Ru";

            alumnoUno.apellido="Ramirez";
            alumnoDos.apellido="Perez";
            alumnoTres.apellido = "Paul";

            alumnoUno.legajo = 1234;
            alumnoDos.legajo = 5678;
            alumnoTres.legajo = 9012;

            alumnoUno.Estudiar(10, 5);
            alumnoDos.Estudiar(3, 2);
            alumnoTres.Estudiar(6, 10);

            alumnoUno.CalcularFinal();
            alumnoDos.CalcularFinal();
            alumnoTres.CalcularFinal();

            Console.WriteLine("DATOS ALUMNO UNO: {0}",alumnoUno.Mostrar());
            Console.WriteLine("DATOS ALUMNO DOS: {0}", alumnoDos.Mostrar());
            Console.WriteLine("DATOS ALUMNO TRES: {0}", alumnoTres.Mostrar());
            Console.ReadKey();
        }
    }
}
