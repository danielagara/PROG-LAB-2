﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_16_c
{
    public class Alumno
    {
        byte nota1;
        byte nota2;
        float notaFinal;
        public string apellido;
        public int legajo;
        public string nombre;
        static Random randomUsar = new Random();
        
        
        public void CalcularFinal()
        {
            
            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal=(float)randomUsar.Next(10);
            }
            else
            {
                this.notaFinal=-1;
            }
        }

        public void Estudiar(byte notaUno, byte notaDos)
        {
            this.nota1 = notaUno;
            this.nota2 = notaDos;
        }

        public string Mostrar()
        {
            StringBuilder stringBuilderUsar = new StringBuilder();

            stringBuilderUsar.AppendLine(this.nombre);
            stringBuilderUsar.AppendLine(this.apellido);
            stringBuilderUsar.AppendLine(this.legajo.ToString());
            stringBuilderUsar.AppendLine(this.nota1.ToString());
            stringBuilderUsar.AppendLine(this.nota2.ToString());
            if (this.notaFinal > -1)
            {
                stringBuilderUsar.AppendLine(this.notaFinal.ToString());
 
            }
            //stringBuilderUsar.AppendLine(this.legajo);
            return stringBuilderUsar.ToString();
        }
    }

    


}
