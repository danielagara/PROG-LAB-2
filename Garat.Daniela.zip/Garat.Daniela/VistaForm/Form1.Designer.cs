﻿namespace VistaForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbpDatosCurso = new System.Windows.Forms.GroupBox();
            this.lblAnioCurso = new System.Windows.Forms.Label();
            this.lblDivisionCurso = new System.Windows.Forms.Label();
            this.lblnNombreProfesor = new System.Windows.Forms.Label();
            this.lblApellidoProfesor = new System.Windows.Forms.Label();
            this.lblDniProfesor = new System.Windows.Forms.Label();
            this.lblFechaDeIngreso = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.nudAnioCurso = new System.Windows.Forms.NumericUpDown();
            this.nudAnioAlumno = new System.Windows.Forms.NumericUpDown();
            this.cmbDivisionCurso = new System.Windows.Forms.ComboBox();
            this.cmbDivisionAlumno = new System.Windows.Forms.ComboBox();
            this.dtpIngreso = new System.Windows.Forms.DateTimePicker();
            this.txtNombreProfesor = new System.Windows.Forms.TextBox();
            this.txtApellidoProfesor = new System.Windows.Forms.TextBox();
            this.txtDocumentoProfesor = new System.Windows.Forms.TextBox();
            this.txtNombreAlumno = new System.Windows.Forms.TextBox();
            this.txtApellidoAlumno = new System.Windows.Forms.TextBox();
            this.txtLegajoAlumno = new System.Windows.Forms.TextBox();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.btnMostrar = new System.Windows.Forms.Button();
            this.btnCrear = new System.Windows.Forms.Button();
            this.rtbDatos = new System.Windows.Forms.RichTextBox();
            this.gbpDatosCurso.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnioCurso)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnioAlumno)).BeginInit();
            this.SuspendLayout();
            // 
            // gbpDatosCurso
            // 
            this.gbpDatosCurso.Controls.Add(this.btnCrear);
            this.gbpDatosCurso.Controls.Add(this.btnMostrar);
            this.gbpDatosCurso.Controls.Add(this.txtDocumentoProfesor);
            this.gbpDatosCurso.Controls.Add(this.txtApellidoProfesor);
            this.gbpDatosCurso.Controls.Add(this.txtNombreProfesor);
            this.gbpDatosCurso.Controls.Add(this.dtpIngreso);
            this.gbpDatosCurso.Controls.Add(this.cmbDivisionCurso);
            this.gbpDatosCurso.Controls.Add(this.nudAnioCurso);
            this.gbpDatosCurso.Controls.Add(this.lblFechaDeIngreso);
            this.gbpDatosCurso.Controls.Add(this.lblDniProfesor);
            this.gbpDatosCurso.Controls.Add(this.lblApellidoProfesor);
            this.gbpDatosCurso.Controls.Add(this.lblnNombreProfesor);
            this.gbpDatosCurso.Controls.Add(this.lblDivisionCurso);
            this.gbpDatosCurso.Controls.Add(this.lblAnioCurso);
            this.gbpDatosCurso.Location = new System.Drawing.Point(12, 12);
            this.gbpDatosCurso.Name = "gbpDatosCurso";
            this.gbpDatosCurso.Size = new System.Drawing.Size(267, 295);
            this.gbpDatosCurso.TabIndex = 0;
            this.gbpDatosCurso.TabStop = false;
            this.gbpDatosCurso.Text = "DatosDelCurso";
            // 
            // lblAnioCurso
            // 
            this.lblAnioCurso.AutoSize = true;
            this.lblAnioCurso.Location = new System.Drawing.Point(6, 30);
            this.lblAnioCurso.Name = "lblAnioCurso";
            this.lblAnioCurso.Size = new System.Drawing.Size(26, 13);
            this.lblAnioCurso.TabIndex = 1;
            this.lblAnioCurso.Text = "Año";
            // 
            // lblDivisionCurso
            // 
            this.lblDivisionCurso.AutoSize = true;
            this.lblDivisionCurso.Location = new System.Drawing.Point(7, 62);
            this.lblDivisionCurso.Name = "lblDivisionCurso";
            this.lblDivisionCurso.Size = new System.Drawing.Size(44, 13);
            this.lblDivisionCurso.TabIndex = 2;
            this.lblDivisionCurso.Text = "Division";
            // 
            // lblnNombreProfesor
            // 
            this.lblnNombreProfesor.AutoSize = true;
            this.lblnNombreProfesor.Location = new System.Drawing.Point(10, 101);
            this.lblnNombreProfesor.Name = "lblnNombreProfesor";
            this.lblnNombreProfesor.Size = new System.Drawing.Size(44, 13);
            this.lblnNombreProfesor.TabIndex = 3;
            this.lblnNombreProfesor.Text = "Nombre";
            // 
            // lblApellidoProfesor
            // 
            this.lblApellidoProfesor.AutoSize = true;
            this.lblApellidoProfesor.Location = new System.Drawing.Point(9, 138);
            this.lblApellidoProfesor.Name = "lblApellidoProfesor";
            this.lblApellidoProfesor.Size = new System.Drawing.Size(44, 13);
            this.lblApellidoProfesor.TabIndex = 4;
            this.lblApellidoProfesor.Text = "Apellido";
            // 
            // lblDniProfesor
            // 
            this.lblDniProfesor.AutoSize = true;
            this.lblDniProfesor.Location = new System.Drawing.Point(10, 167);
            this.lblDniProfesor.Name = "lblDniProfesor";
            this.lblDniProfesor.Size = new System.Drawing.Size(26, 13);
            this.lblDniProfesor.TabIndex = 5;
            this.lblDniProfesor.Text = "DNI";
            // 
            // lblFechaDeIngreso
            // 
            this.lblFechaDeIngreso.AutoSize = true;
            this.lblFechaDeIngreso.Location = new System.Drawing.Point(10, 197);
            this.lblFechaDeIngreso.Name = "lblFechaDeIngreso";
            this.lblFechaDeIngreso.Size = new System.Drawing.Size(42, 13);
            this.lblFechaDeIngreso.TabIndex = 6;
            this.lblFechaDeIngreso.Text = "Ingreso";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnAgregar);
            this.groupBox1.Controls.Add(this.txtLegajoAlumno);
            this.groupBox1.Controls.Add(this.txtApellidoAlumno);
            this.groupBox1.Controls.Add(this.txtNombreAlumno);
            this.groupBox1.Controls.Add(this.cmbDivisionAlumno);
            this.groupBox1.Controls.Add(this.nudAnioAlumno);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Location = new System.Drawing.Point(376, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(293, 295);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "DatosDelAlumno";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Legajo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(5, 62);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Apellido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(5, 30);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Nombre";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 167);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Division";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 138);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(26, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Año";
            // 
            // nudAnioCurso
            // 
            this.nudAnioCurso.Location = new System.Drawing.Point(81, 28);
            this.nudAnioCurso.Name = "nudAnioCurso";
            this.nudAnioCurso.Size = new System.Drawing.Size(120, 20);
            this.nudAnioCurso.TabIndex = 6;
            // 
            // nudAnioAlumno
            // 
            this.nudAnioAlumno.Location = new System.Drawing.Point(99, 136);
            this.nudAnioAlumno.Name = "nudAnioAlumno";
            this.nudAnioAlumno.Size = new System.Drawing.Size(120, 20);
            this.nudAnioAlumno.TabIndex = 7;
            // 
            // cmbDivisionCurso
            // 
            this.cmbDivisionCurso.FormattingEnabled = true;
            this.cmbDivisionCurso.Location = new System.Drawing.Point(81, 62);
            this.cmbDivisionCurso.Name = "cmbDivisionCurso";
            this.cmbDivisionCurso.Size = new System.Drawing.Size(121, 21);
            this.cmbDivisionCurso.TabIndex = 7;
            // 
            // cmbDivisionAlumno
            // 
            this.cmbDivisionAlumno.FormattingEnabled = true;
            this.cmbDivisionAlumno.Location = new System.Drawing.Point(99, 167);
            this.cmbDivisionAlumno.Name = "cmbDivisionAlumno";
            this.cmbDivisionAlumno.Size = new System.Drawing.Size(121, 21);
            this.cmbDivisionAlumno.TabIndex = 8;
            // 
            // dtpIngreso
            // 
            this.dtpIngreso.Location = new System.Drawing.Point(61, 197);
            this.dtpIngreso.Name = "dtpIngreso";
            this.dtpIngreso.Size = new System.Drawing.Size(200, 20);
            this.dtpIngreso.TabIndex = 2;
            // 
            // txtNombreProfesor
            // 
            this.txtNombreProfesor.Location = new System.Drawing.Point(81, 101);
            this.txtNombreProfesor.Name = "txtNombreProfesor";
            this.txtNombreProfesor.Size = new System.Drawing.Size(100, 20);
            this.txtNombreProfesor.TabIndex = 2;
            // 
            // txtApellidoProfesor
            // 
            this.txtApellidoProfesor.Location = new System.Drawing.Point(81, 135);
            this.txtApellidoProfesor.Name = "txtApellidoProfesor";
            this.txtApellidoProfesor.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoProfesor.TabIndex = 8;
            // 
            // txtDocumentoProfesor
            // 
            this.txtDocumentoProfesor.Location = new System.Drawing.Point(81, 168);
            this.txtDocumentoProfesor.Name = "txtDocumentoProfesor";
            this.txtDocumentoProfesor.Size = new System.Drawing.Size(100, 20);
            this.txtDocumentoProfesor.TabIndex = 9;
            // 
            // txtNombreAlumno
            // 
            this.txtNombreAlumno.Location = new System.Drawing.Point(83, 30);
            this.txtNombreAlumno.Name = "txtNombreAlumno";
            this.txtNombreAlumno.Size = new System.Drawing.Size(100, 20);
            this.txtNombreAlumno.TabIndex = 10;
            // 
            // txtApellidoAlumno
            // 
            this.txtApellidoAlumno.Location = new System.Drawing.Point(83, 63);
            this.txtApellidoAlumno.Name = "txtApellidoAlumno";
            this.txtApellidoAlumno.Size = new System.Drawing.Size(100, 20);
            this.txtApellidoAlumno.TabIndex = 11;
            // 
            // txtLegajoAlumno
            // 
            this.txtLegajoAlumno.Location = new System.Drawing.Point(83, 98);
            this.txtLegajoAlumno.Name = "txtLegajoAlumno";
            this.txtLegajoAlumno.Size = new System.Drawing.Size(100, 20);
            this.txtLegajoAlumno.TabIndex = 12;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Location = new System.Drawing.Point(104, 229);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(115, 58);
            this.btnAgregar.TabIndex = 2;
            this.btnAgregar.Text = "Agregar";
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // btnMostrar
            // 
            this.btnMostrar.Location = new System.Drawing.Point(146, 229);
            this.btnMostrar.Name = "btnMostrar";
            this.btnMostrar.Size = new System.Drawing.Size(115, 58);
            this.btnMostrar.TabIndex = 3;
            this.btnMostrar.Text = "Mostrar";
            this.btnMostrar.UseVisualStyleBackColor = true;
            // 
            // btnCrear
            // 
            this.btnCrear.Location = new System.Drawing.Point(6, 229);
            this.btnCrear.Name = "btnCrear";
            this.btnCrear.Size = new System.Drawing.Size(115, 58);
            this.btnCrear.TabIndex = 10;
            this.btnCrear.Text = "Crear Curso";
            this.btnCrear.UseVisualStyleBackColor = true;
            // 
            // rtbDatos
            // 
            this.rtbDatos.Location = new System.Drawing.Point(0, 339);
            this.rtbDatos.Name = "rtbDatos";
            this.rtbDatos.Size = new System.Drawing.Size(706, 242);
            this.rtbDatos.TabIndex = 3;
            this.rtbDatos.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(705, 580);
            this.Controls.Add(this.rtbDatos);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.gbpDatosCurso);
            this.Name = "Form1";
            this.Text = "Vista del Curso";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.gbpDatosCurso.ResumeLayout(false);
            this.gbpDatosCurso.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnioCurso)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudAnioAlumno)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox gbpDatosCurso;
        private System.Windows.Forms.TextBox txtDocumentoProfesor;
        private System.Windows.Forms.TextBox txtApellidoProfesor;
        private System.Windows.Forms.TextBox txtNombreProfesor;
        private System.Windows.Forms.DateTimePicker dtpIngreso;
        private System.Windows.Forms.ComboBox cmbDivisionCurso;
        private System.Windows.Forms.NumericUpDown nudAnioCurso;
        private System.Windows.Forms.Label lblFechaDeIngreso;
        private System.Windows.Forms.Label lblDniProfesor;
        private System.Windows.Forms.Label lblApellidoProfesor;
        private System.Windows.Forms.Label lblnNombreProfesor;
        private System.Windows.Forms.Label lblDivisionCurso;
        private System.Windows.Forms.Label lblAnioCurso;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtLegajoAlumno;
        private System.Windows.Forms.TextBox txtApellidoAlumno;
        private System.Windows.Forms.TextBox txtNombreAlumno;
        private System.Windows.Forms.ComboBox cmbDivisionAlumno;
        private System.Windows.Forms.NumericUpDown nudAnioAlumno;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnCrear;
        private System.Windows.Forms.Button btnMostrar;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.RichTextBox rtbDatos;
    }
}

