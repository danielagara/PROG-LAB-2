﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Profesor : Persona
    {
        #region Atributos
        private DateTime fechaDeIngreso;
        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        public Profesor(string nombre, string apellido, string documento)
        :base(nombre, apellido, documento)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        public Profesor(string nombre, string apellido, string documento, DateTime fechaIngreso)
        :this(nombre, apellido,documento)
        {
            this.fechaDeIngreso = fechaIngreso;
        }
        #endregion

        #region Propiedades
        /// <summary>
        /// 
        /// </summary>
        public int Antiguedad
        {
            get
            {
                int retorno = 0;
                DateTime actual= DateTime.Now;
                retorno = (int)((actual - this.fechaDeIngreso).TotalDays);
                return retorno;
            }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// 
        /// </summary>
        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.ExponerDatos());
            sb.AppendLine(this.Antiguedad.ToString());

            return sb.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        protected override bool ValidarDocumentacion(string documento)
        {
            bool retorno = false;
            if (documento.Length>=8)//revisar
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }

        #endregion

    }
}
