﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public enum Divisiones
    {
        A,
        B,
        C,
        D
    }

    public abstract class Persona
    {
        #region Atributos

        private string apellido;
        private string documento;
        private string nombre;

        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        public Persona(string nombre, string apellido, string documento)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.documento = documento;
        }
        #endregion

        #region Propiedades
        /// <summary>
        /// 
        /// </summary>
        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Documento
        {
            get
            {
                  
                return this.documento;
            }

            set
            {
                this.documento = value;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
        }

        #endregion

        #region Metodos
        /// <summary>
        /// 
        /// </summary>
        virtual public string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("NOMBRE: " + this.Nombre);
            sb.AppendLine("APELLIDO: " + this.Apellido);
            sb.AppendLine("DOCUMENTO: " + this.Documento);

            return sb.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        protected abstract bool ValidarDocumentacion(string documento);
        #endregion
    }
}
