﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Curso
    {
        #region Atributos
        private List<Alumno> alumnos;
        private short anio;
        private Divisiones division;
        private Profesor profesor;
        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        private Curso()
        {
            this.alumnos = new List<Alumno>();
        }

        /// <summary>
        /// 
        /// </summary>
        public Curso(short anio, Divisiones division, Profesor profesor)
            :this()
        {
            this.anio = anio;
            this.division = division;
            this.profesor = profesor;
        }

        #endregion

        #region Propiedades
        /// <summary>
        /// 
        /// </summary>
        public string AnioDivision
        {
            get
            {
                //revisar
                return String.Format("{0}º{1}", this.anio.ToString(), this.division.ToString());
            }
        }
        #endregion

        #region Operadores
        /// <summary>
        /// 
        /// </summary>
        public static explicit operator string(Curso c)
        {
            StringBuilder sb=new StringBuilder();
            sb.AppendLine("AÑO DIVISION: "+c.AnioDivision);
            sb.AppendLine("PROFESOR: " + c.profesor.ExponerDatos());
            for(int i=0; i<c.alumnos.Count;i++)
            {
                sb.AppendLine(((Alumno)c.alumnos[i]).ExponerDatos());
            }

            return sb.ToString();
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool operator ==(Curso c, Alumno a)
        {
            bool retorno = false;
            for (int i = 0; i < c.alumnos.Count; i++)
            {
                if (c.alumnos[i].AnioDivision == a.AnioDivision)
                {
                    retorno = true;
                    break;
                }
            }

            return retorno;
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool operator !=(Curso c, Alumno a)
        {
            return !(c == a);
        }

        /// <summary>
        /// 
        /// </summary>
        public static Curso operator +(Curso c, Alumno a)
        {

            if (c == a)
            {
                c.alumnos.Add(a);
            }
            return c;
        }
        #endregion
    }
}
