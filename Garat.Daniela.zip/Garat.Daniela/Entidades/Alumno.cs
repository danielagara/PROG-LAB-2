﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Alumno : Persona
    {
        #region Atributos

        private short anio;
        private Divisiones division;
        #endregion

        #region Constructores
        /// <summary>
        /// 
        /// </summary>
        public Alumno(string nombre, string apellido, string documento, short anio, Divisiones division)
        :base(nombre, apellido, documento)
        {
            this.anio=anio;
            this.division = division;
        }

        #endregion

        #region Propiedades
        /// <summary>
        /// 
        /// </summary>
        public string AnioDivision
        {
            get
            {
                //revisar
                return String.Format("{0}º{1}", this.anio.ToString(), this.division.ToString());
            }
        }
        #endregion

        #region Metodos
        /// <summary>
        /// 
        /// </summary>
        public override string ExponerDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(base.ExponerDatos());
            sb.AppendLine(this.AnioDivision);

            return sb.ToString();
        }

        protected override bool ValidarDocumentacion(string documento)
        {
            bool retorno = false;
            if (documento.Length>=8)//revisar
            {
                retorno = true;
            }
            else
            {
                retorno = false;
            }

            return retorno;
        }

        #endregion
    }
}
