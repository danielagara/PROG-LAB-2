﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> numeros = new List<int>();
            int sumNumeros=0;
            for(int i=0;i<5;i++)
            {
                Console.WriteLine("INGRESE EL NUMERO");
                string numAux=Console.ReadLine();
                numeros.Add(Int16.Parse(numAux));
                sumNumeros = sumNumeros + numeros[i];
            }

            /*foreach (int nums in numeros)
            {
                Console.WriteLine(nums);
            }*/

            int numMax = numeros.Max();
            Console.WriteLine("MAXIMO = {0}",numMax);
            int numMin = numeros.Min();
            Console.WriteLine("MINIMO = {0}", numMin);
            float numProm =(float) sumNumeros / numeros.Count;
            Console.WriteLine("PROMEDIO = {0}", numProm);
            //revisar como imprime el promedio
        }
    }
}
