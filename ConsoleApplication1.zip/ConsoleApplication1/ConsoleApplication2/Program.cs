﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            double numeroCuadrado;
            double numeroCubo;

            Console.WriteLine("INGRESE UN NUMERO MAYOR A 0");
            string numAux = Console.ReadLine();
            numero = Int16.Parse(numAux);
            if (numero > 0)
            {
                numeroCuadrado = Math.Pow(numero, 2);
                numeroCubo = Math.Pow(numero, 3);
                Console.WriteLine("EL CUADRADO DE {0} ES {1}, Y EL CUBO ES {2}", numero, numeroCuadrado, numeroCubo);
            }
            else
            {
                Console.WriteLine("ERROR VOLVER A INGRESAR");
            }

        }
    }
}
