﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Ejercicio_51
{
    public class Local : Llamada, IGuardar<Local>
    {
        protected float _costo;
        private string rutaArchivo;

        #region PROPERTIES
        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }

        public string RutaDeArchivo
        {
            get
            {
                return this.rutaArchivo;
            }

            set
            {
                this.rutaArchivo = value;
            }
        }
        #endregion PROPERTIES

        #region METHODS
        public Local(Llamada llamada1, float costo)
            : this(llamada1.Duracion, llamada1.NroDestino, llamada1.NroOrigen, costo)
        {

        }

        public Local(float duracion, string destino, string origen, float costo)
            : base(duracion, destino, origen)
        {
            this._costo = costo;
        }

        private float CalcularCosto()
        {
            return base.Duracion * this._costo;
        }

        protected override string Mostrar()
        {
            StringBuilder xStr = new StringBuilder();
            xStr.Append(base.Mostrar());
            xStr.AppendLine("Costo: " + this.CostoLlamada);
            return xStr.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        public override bool Equals(object obj)
        {
            return (obj is Local);
        }

        public bool Guardar()
        {
            StreamWriter myStw = null;
            try
            {
                myStw = new StreamWriter(@"D:\DG\Ejercicio_51\prueba.txt", true);
                myStw.WriteLine(this.Mostrar());
            }
            catch(Exception e){
            }
            finally
            {
                myStw.Close();
            }
            return true;
        }

        public Local Leer()
        {
            StreamReader myStr = new StreamReader("D:/DG/Ejercicio_51/prueba.txt");
            string texto= myStr.ReadToEnd();
            
            throw new NotImplementedException();
        }
        #endregion METHODS
    }
}
