﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_51
{
    public class Centralita : IGuardar<string>
    {
        #region FIELDS
        protected string razonSocial;
        private List<Llamada> listaDeLlamadas;
        private string rutaArchivo;
        #endregion FIELDS

        #region PROPERTIES
        public string RutaDeArchivo
        {
            get { return this.rutaArchivo; }
            set { this.rutaArchivo = value; }
        }

        public float GananciasPorLocal
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }

        public float GananciasPorProvincial
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }

        public float GananciaTotal
        {
            get
            {
                return this.CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }

        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }
        #endregion PROPERTIES

        #region METHODS
        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
        }

        public Centralita(string razonSocial)
            : this()
        {
            this.razonSocial = razonSocial;
        }

        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            float xCosto = 0F;
            foreach (Llamada xItem in this.Llamadas)
            {
                switch (tipo)
                {
                    case Llamada.TipoLlamada.Local:
                        if (xItem is Local)
                            xCosto += ((Local)xItem).CostoLlamada;
                        break;

                    case Llamada.TipoLlamada.Provincial:
                        if (xItem is Provincial)
                            xCosto += ((Provincial)xItem).CostoLlamada;
                        break;

                    default:
                        if (xItem is Local)
                            xCosto += ((Local)xItem).CostoLlamada;
                        if (xItem is Provincial)
                            xCosto += ((Provincial)xItem).CostoLlamada;
                        break;
                }
            }
            return xCosto;
        }

        public bool Guardar()
        {
            string xResult = "";
            xResult = this.ToString();
            return true;
        }

        public string Leer()
        {
            throw new NotImplementedException();
        }


        public void OrdenarLlamadas()
        {
            this.Llamadas.Sort(Llamada.OrdenarPorDuracion);
        }

        protected string Mostrar()
        {
            StringBuilder xStr = new StringBuilder();
            xStr.AppendLine("Central: " + this.razonSocial);
            foreach (Llamada xItem in this.Llamadas)
            {
                if (xItem is Local)
                    xStr.AppendLine(((Local)xItem).ToString());
                else
                {
                    if (xItem is Provincial)
                        xStr.AppendLine(((Provincial)xItem).ToString());
                }

            }
            xStr.AppendLine("");
            xStr.AppendLine("Ganancias por Local: " + this.GananciasPorLocal);
            xStr.AppendLine("Ganancias por Provincial: " + this.GananciasPorProvincial);
            xStr.AppendLine("Ganancia Total: " + this.GananciaTotal);
            return xStr.ToString();
        }

        public override string ToString()
        {
            return this.Mostrar();
        }

        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            this.Llamadas.Add(nuevaLlamada);
        }
        #endregion METHODS

        #region OPERADORES
        public static bool operator ==(Centralita c, Llamada l1)
        {
            bool xReturn = false;
            foreach (Llamada xItem in c.Llamadas)
            {
                if (xItem == l1)
                {
                    xReturn = true;
                    break;
                }
            }
            return xReturn;
        }

        public static bool operator !=(Centralita c, Llamada l1)
        {
            return (!(c == l1));
        }

        public static Centralita operator +(Centralita c, Llamada nuevaLlamada)
        {
            if (c != nuevaLlamada)
                c.AgregarLlamada(nuevaLlamada);
            else
            {
                CentralitaExcepcion cException = new CentralitaExcepcion("Llamada existente!!", "Centralita","Operador +");
                throw cException;
            }
            return c;
        }
        #endregion OPERADORES
    }
}

