﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ejercicio_51;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ValidaInstanciaLista()
        {
            Centralita central = new Centralita("Dipi Center");
            Assert.IsNotNull(central.Llamadas);
        }

        [TestMethod]
        public void ValidaCentralitaExceptionLocal()
        {
            Centralita central = new Centralita("Dipi Center");
            Local l1 = new Local(30, "Escalada", "Lomas de Zamora", 0.5F);
            Local l2 = new Local(30, "Escalada", "Lomas de Zamora", 0.5F);
            central += l1;
            try
            {
                central += l2;
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(CentralitaExcepcion));
                //Assert.IsTrue((e is CentralitaExcepcion));
            }
        }

        [TestMethod]
        public void ValidaCentralitaExceptionProvincial()
        {
            Centralita central = new Centralita("Dipi Center");
            Provincial p1 = new Provincial("Buenos Aires", Provincial.Franja.Franja_2, 50, "Salta");
            Provincial p3 = new Provincial("Buenos Aires", Provincial.Franja.Franja_2, 50, "Salta");
            central += p1;
            try
            {
                central += p3;
                Assert.Fail("no dio excepcion");
            }
            catch (Exception e)
            {
                Assert.IsInstanceOfType(e, typeof(CentralitaExcepcion));
                //Assert.IsTrue((e is CentralitaExcepcion)); tambien se puede
            }
        }

        [TestMethod]
        public void ComparaLlamadas()
        {
            Centralita central = new Centralita("Dipi Center");
            Local local1 = new Local(30, "Escalada", "Lomas de Zamora", 0.5F);
            Local local3 = new Local(30, "Escalada", "Lomas de Zamora", 0.5F);
            Provincial prov1 = new Provincial("Buenos Aires", Provincial.Franja.Franja_2, 50, "Salta");
            Provincial prov3 = new Provincial("Buenos Aires", Provincial.Franja.Franja_2, 50, "Salta");

            if (!((local1 != prov1) || (local3 != prov3) || (local3 != prov1) || (local1 != prov3)))
                Assert.Fail("Hubo un error");
            Assert.IsFalse((prov1 != prov3) && (local1 != local3));
        }
    }
}
