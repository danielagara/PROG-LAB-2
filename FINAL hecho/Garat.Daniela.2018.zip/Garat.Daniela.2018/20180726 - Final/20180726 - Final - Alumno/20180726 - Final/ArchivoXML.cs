﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.IO;
using System.Xml.Serialization;
using System.Xml;

namespace _20180726___Final
{
    public class ArchivoXML : IArchivos<bool, Sofa>
    {
        public bool Guardar(string path, Sofa elemento)
        { 
            XmlTextWriter writer;  
            XmlSerializer ser;
            writer = new XmlTextWriter(path, UTF8Encoding.UTF8);

            ser = new XmlSerializer(typeof(Sofa));

            ser.Serialize(writer, elemento);

            writer.Close();
            return true;
        }
        
        public Sofa Leer(string path)
        {
            XmlTextReader reader;
            XmlSerializer ser;
            reader = new XmlTextReader(path);

            ser = new XmlSerializer(typeof(Sofa));

            Sofa aux = (Sofa)ser.Deserialize(reader);

            reader.Close();
            return aux;
        }
        

    }
}
