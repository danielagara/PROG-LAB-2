﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
using System.IO;

namespace _20180726___Final
{
    public class ArchivoTexto : IArchivos<bool, string>
    {
        public bool Guardar(string path, string elemento)
        {
            try
            {
                StreamWriter myStw = null;
                myStw = new StreamWriter(path, true);
                myStw.WriteLine(elemento);
                myStw.Close();
            }
            catch (FileNotFoundException fnfEx)
            {
                throw fnfEx;
            }
            catch (IOException ioEx)
            {

                throw ioEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }
        public string Leer(string path)
        {
            string retorno = "";
            StreamReader mystm = new StreamReader(path);
            retorno= mystm.ReadToEnd();
            mystm.Close();
            return retorno;
        }
    }
}
