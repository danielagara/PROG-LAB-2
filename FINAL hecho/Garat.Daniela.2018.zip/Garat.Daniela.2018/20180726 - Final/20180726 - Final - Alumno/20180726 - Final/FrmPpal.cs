﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using Entidades;
using System.IO;

namespace _20180726___Final
{
    // Reutilizar tanto código como sea posible.
    // Primer Parcial: Agregar un atributo del tipo Muebleria e instanciarlo en el constructor.
    // Segundo Parcial y Final
    //   - Agregar un atributo del tipo Lista de Asiento e instanciarlo en el constructor.
    //   - Controlar excepciones en archivos.
    //   - Para el manejo de archivos agregar una interfaz genérica con los métodos V Guardar(string path, T elemento) y T Leer(string path)
    //   - Generar dos clases: ArchivoTexto y ArchivoXML que implementen dicha interfaz. Completar los métodos según corresponda.
    //   - Probar todos los asientos mediante un Thread. Crear un evento FinPruebaCalidad() en Asiento para que informe si la prueba pasó (true) o no (false) y mostrar el resultado por pantalla.
    public partial class FrmPpal : Form
    {
        public List<Asiento> lista;
        public Thread hilo;  

        public FrmPpal()
        {
            InitializeComponent();

            this.lista = new List<Asiento>();
        }

        /// <summary>
        /// Primer Parcial: Agregar el elemento a la mueblería.
        /// Segundo Parcial y Final: Al presionar el botón agregar se deberá guardar la información a un archivo, anexando el nuevo Asiento al final. Agregar el elemento a la lista.
        /// Luego, leer el archivo y mostrarlo en el RichTextBox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Random myrandom = new Random();
            Sofa mysofa = new Sofa((short)nudAncho.Value, (short)nudAlto.Value, (short)nudProfundidad.Value, (Sofa.ColorSofa)myrandom.Next(1, 4));
            this.lista.Add(mysofa);

            ArchivoTexto archivo = new ArchivoTexto();
            string path = String.Format(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\listaAsientos.txt");
            archivo.Guardar(path, mysofa.ToString());
            rtbMensaje.Text = archivo.Leer(path);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ArchivoTexto archivo = new ArchivoTexto();
            string path = String.Format(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\listaAsientos.txt");
            rtbMensaje.Text = archivo.Leer(path);
        }

        /// <summary>
        /// Antes de cerrar, serializar la lista en XML. Hacer las modificaciones necesarias para guardar todos los datos.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.hilo.IsAlive)
            {
                this.hilo.Abort();
            }

            ArchivoXML archivo = new ArchivoXML();
            string path = String.Format(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\listaAsientosSerializada");
            foreach (Asiento asiento in this.lista)
            {
                archivo.Guardar(path, (Sofa)asiento);
            }
        }

        public void BancoDePrueba()
        {
            foreach (Asiento asiento in this.lista)
            {
                asiento.ProbarAsiento();
                MessageBox.Show("La prueba ha finalizado");
            }
        }

        private void btnProbar_Click(object sender, EventArgs e)
        {
            this.hilo = new Thread(this.BancoDePrueba);
            this.hilo.Start();
        }


    }
}
