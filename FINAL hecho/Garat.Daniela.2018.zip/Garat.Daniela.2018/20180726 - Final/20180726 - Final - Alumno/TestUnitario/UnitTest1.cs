﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using _20180726___Final;

namespace TestUnitario
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Sofa sofa = new Sofa(1, 2, 3, Sofa.ColorSofa.Blanco);
            ArchivoXML archivo = new ArchivoXML();
            string path = String.Format(Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\listaAsientosSerializada");


            archivo.Guardar(path, (sofa));

            Sofa sofa2 = (Sofa)archivo.Leer(path);
            Console.WriteLine("sofa 1: {0}, sofa 2 : {1}", sofa.ToString(), sofa2.ToString());
        }
    }
}
