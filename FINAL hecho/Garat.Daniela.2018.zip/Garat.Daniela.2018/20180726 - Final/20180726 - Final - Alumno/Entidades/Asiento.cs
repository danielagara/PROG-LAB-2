﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    // Redefinir ToString para que retorne la información del Asiento de forma ordenada. Utilizar string.Format o StringBuilder.
    // Utilizar la teoría de encapsulamiento en todas las clases.
    // La clase debe ser abstracta
    // Crear un método abstracto llamado ProbarAsiento que retorne un bool.
    public abstract class Asiento
    {
        public short alto;
        public short ancho;
        public short profundidad;

        public delegate void Final(object sender, EventArgs e);

        public event Final FinalPrueba;
        public Asiento()
        { }
        public Asiento(short alto, short ancho, short profundidad)
        {
            this.alto = alto;
            this.ancho = ancho;
            this.profundidad = profundidad;
        }

        public override string ToString()
        {
            StringBuilder mysb = new StringBuilder();

            mysb.AppendLine("Alto:" + this.alto.ToString() + "Ancho:" + this.ancho.ToString() + "Profundidad:" + this.profundidad.ToString());
            return mysb.ToString();
        }

        public abstract void ProbarAsiento();

        public void InformarFinDePrueba(bool resultado)
        {
            if (resultado == true)
            {
                this.FinalPrueba.Invoke(this, EventArgs.Empty);
            }
        }
    }
}
