﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    

    // Agregar un enumerado con los colores: Natural, Blanco, Negro, Rojo. Utilizar este enumerado en el atributo color de Sofa.
    // Generar una relación de herencia entre Asiento y Sofa.
    // Modificar los atributos y constructores según crea necesario.
    // El método ProbarAsiento hará un Sleep de 3 segundos y retornará true o false de forma aleatoria (Random).

    // Utilizar la teoría de encapsulamiento en todas las clases.
    public class Sofa : Asiento
    {
        public enum ColorSofa
        {
            Natural=1,
            Blanco=2,
            Negro=3,
            Rojo=4,
        }

        public ColorSofa color;
        public Sofa()
        { }

        private Sofa(short alto, short ancho, short profundidad)
        :base(alto, ancho, profundidad)
        {
            
        }

        public Sofa(short alto, short ancho, short profundidad, ColorSofa color)
            : base(alto, ancho, profundidad)
        {
            this.alto = alto;
            this.ancho = ancho;
            this.profundidad = profundidad;
            this.color = color;
        }

        public override void ProbarAsiento()
        {
            //bool retorno=false;
            Random myrandom = new Random();
            System.Threading.Thread.Sleep(5000);
            if (myrandom.Next(0, 1) >= 1)
            {
                base.InformarFinDePrueba(true);
            }
            else
            {
                base.InformarFinDePrueba(false);
            }
            //return retorno;
        }

        public override string ToString()
        {
            StringBuilder mysb = new StringBuilder();

            mysb.AppendLine("Alto:" + this.alto.ToString() + "Ancho:" + this.ancho.ToString() + "Profundidad:" + this.profundidad.ToString()+ "Color: " + this.color.ToString());
            return mysb.ToString();
        }
    }
}
