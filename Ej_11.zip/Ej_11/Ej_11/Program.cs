﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ej_11
{
    class Program
    {
        static void Main(string[] args)
        {
            Validacion validar= new Validacion();

            int num;
            int numMin=0;
            int numMax=0;
            int sumador=0;

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine("INGRESE EL NUMERO {0}", i);
                num =Int16.Parse(Console.ReadLine());
                if (validar.Validar(num, -100, 100) == true)
                {
                    sumador = sumador + num;
                    if (i == 1)
                    {
                        numMin = num;
                        numMax = num;
                    }
                    else
                    {
                        if (num < numMin)
                        {
                            numMin = num;
                        }

                        if (num > numMax)
                        {
                            numMax = num;
                        }
                    }
                }
            }
            Console.WriteLine("NUM MIN: {0}", numMin);
            Console.WriteLine("NUM MAX: {0}", numMax);
            Console.WriteLine("PROMEDIO: {0}", sumador / 10);
            Console.ReadKey();
        }
    }
}
